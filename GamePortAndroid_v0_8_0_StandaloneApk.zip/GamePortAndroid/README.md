# GamePort Android — v0.8.0 (standalone game APKs; see CHANGELOG_v0.8.md)

# GamePort Android — v0.7.0

**What works in the code:** import a game ZIP -> unpack to private storage -> detect the game exe -> list it with Play, a home-screen icon and Delete -> fullscreen game screen with a working multitouch controller.
**What is missing:** the runtime that actually runs a Windows game (Wine + Box64 + Vulkan, e.g. built from Winlator's open-source code; check its license). Implement `RuntimeBridge` and return it from `GameRuntime.create()`.
**Update install:** versionCode is 7 (above v0.6's 6). Build with the same MobileStudio install so the debug signing key matches, then install over the existing app.
**Limits:** big zips take a long time to unpack; keep the app open and the screen on until it finishes. Games using anti-cheat will not run online. Not compiled or device-tested yet: if the build shows errors, send them over.

---

# GamePort Android — v0.6.1 Update-ready project

**Update compatibility:** applicationId remains `com.gameport.mobile` and this revision raises versionCode to `2` / versionName to `0.6.1`, so Android can treat it as an update to an installed v0.6 APK **if it was signed with the same signing certificate**. Keep the same MobileStudio installation and its debug signing key for future debug builds; do not clear IDE app data or change signing keys. APKs signed with a different key cannot update in-place.

## Phone-only build (MobileStudio)
1. Install MobileStudio from its official GitHub project/releases: https://github.com/MobileStudio-AndroidIDE/MobileStudio_AndroidIDE
2. Download this ZIP and extract it using your phone's file manager or ZArchiver.
3. In MobileStudio, open/import an existing Gradle project. Select the extracted `GamePortAndroid` folder (the folder containing `settings.gradle`).
4. Let project sync finish and install/download requested SDK/build components if MobileStudio prompts.
5. Use Build (or Build APK) and choose the debug APK variant if prompted.
6. Wait for build completion. The debug APK should be at `app/build/outputs/apk/debug/app-debug.apk` within the project.
7. Open the APK from MobileStudio's build output/install prompt or file manager and install. Approve Android's install prompt.
8. If Android offers **Update** (or just Install with existing app detected), confirm. If it says the package conflicts or signatures differ, STOP—do not uninstall if you want to preserve app data; send a screenshot of the exact error.

## Update/signing caveat
This source project keeps the same package ID and increments the version number, but source alone cannot guarantee update compatibility. Android requires the new APK to use the same signing certificate as the installed app. Debug APKs from the same IDE installation normally use that IDE's persistent debug keystore. Keep that keystore/IDE installation safe for future updates. If the prior APK was signed by another IDE/key, Android may refuse an in-place update.

---

# GamePort Android — v0.6 Port Workbench

**Status:** prototype source project. Android compilation and device testing remain unverified in this environment.


## What v0.6 adds
- Persist imported library entries across restarts.
- Persist touch-layout preset, size, and opacity settings automatically.
- Remove imported library entries.
- Heuristic port-readiness score with explanatory assessment.
- Versioned v0.6 text report.

## Features carried forward from v0.5
- Import a game directory through Android's Storage Access Framework (folder access remains user-selected).
- Import a single file such as a Windows `.exe` for a quick file-level record.
- Recursive inventory scan (depth limit 16), file counts, approximate size, and extension histogram.
- Engine/project heuristics for Unreal, Unity, and Godot; source/project marker check; common settings/config candidates.
- Basic anti-cheat filename indicator (diagnostic only; does not bypass or disable protections).
- Text assessment export and JSON inventory export.
- Touch Layout Designer with FPS, twin-stick, driving, and minimal presets, adjustable scale and opacity, preview, and JSON profile export.

## What is not implemented yet
- There is no universal EXE-to-APK conversion engine.
- The touch designer currently exports layout metadata; it does not inject input into a game.
- No engine SDK is bundled. Unreal/Unity/Godot native Android exports require compatible project/source, engine version, plugins, SDK/NDK, and build configuration.
- APK build/sign/export backend is not yet implemented.
- No runtime bypasses, anti-cheat disabling, or PC-game streaming.

## Build
Open the `GamePortAndroid` folder in a recent Android Studio version with a compatible Android SDK installed. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile/target SDK 35, min SDK 26, and AndroidX DocumentFile 1.0.1. Gradle sync/build has not been verified in this environment (no Android SDK or Gradle executable was available during this update).

## Hood Warfare 2 test target
Treat Hood Warfare 2 as a compatibility/diagnostic benchmark only. Its packaged Windows install is not a substitute for the UE5 source project. A genuine Android port would require legitimate project/source access and a UE Android build setup with compatible plugins and dependencies. The game reportedly uses Easy Anti-Cheat; GamePort does not attempt to bypass it.

## Next work items
1. Build and test on Android Studio/device; fix compiler/runtime issues.
2. Add drag positioning and adjustable hitboxes to the touch-layout editor.
3. Add source-project validation for engine-specific Android build targets.
4. Implement an engine-specific APK build pipeline only where project files/toolchains are present.
