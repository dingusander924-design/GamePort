package com.gameport.mobile

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.android.apksig.ApkSigner
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Date
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import javax.security.auth.x500.X500Principal

/**
 * Builds a standalone per-game APK by cloning GamePort itself:
 *  1. copy GamePort's installed APK,
 *  2. rewrite its binary manifest (new package ID + game name),
 *  3. add assets/gameport_game.json so the clone boots straight into "game mode" (see GameBoot.kt),
 *  4. sign it with a key kept in the Android Keystore (same key for every clone, so updates work).
 * The game files are NOT inside the APK: the clone unpacks the user's own zip on first launch.
 */
object ApkForge {
    private const val BASE_PKG = "com.gameport.mobile"
    private const val BASE_LABEL = "GamePort"
    private const val ALIAS = "gameport_signer"

    /** Stable per game, so rebuilding the same game updates the installed clone in place. */
    fun packageFor(game: PortedGame) = "com.gameport.g" + game.id.filter { it.isLetterOrDigit() }.lowercase()

    fun forge(ctx: Context, game: PortedGame, onProgress: (String) -> Unit): File {
        val info = ctx.applicationInfo
        if (!info.splitSourceDirs.isNullOrEmpty()) throw IllegalStateException("GamePort is installed as split APKs. Install a single debug APK build instead.")
        val src = File(info.sourceDir)
        val newPkg = packageFor(game)
        val work = File(ctx.cacheDir, "forge").apply { mkdirs() }
        val unsigned = File(work, "$newPkg-unsigned.apk")
        val signed = File(work, "$newPkg.apk")
        unsigned.delete(); signed.delete()

        onProgress("Patching app identity…")
        val label = game.title.trim().ifEmpty { "Game" }.take(30)
        val replacements = mapOf(
            BASE_PKG to newPkg,
            BASE_LABEL to label,
            "$BASE_PKG.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION" to "$newPkg.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION"
        )
        val config = JSONObject().put("title", label).put("exe", game.exe).toString().toByteArray(Charsets.UTF_8)
        writeClone(src, unsigned, replacements, config)

        onProgress("Signing…")
        sign(unsigned, signed)
        unsigned.delete()
        return signed
    }

    private fun isOldSignature(n: String) = n.startsWith("META-INF/") &&
        (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC") || n == "META-INF/MANIFEST.MF")

    private class CountingOut(out: OutputStream) : FilterOutputStream(out) {
        var n = 0L
        override fun write(b: Int) { out.write(b); n++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); n += len }
    }

    private fun writeClone(src: File, dst: File, repl: Map<String, String>, config: ByteArray) {
        ZipFile(src).use { zf ->
            val cnt = CountingOut(FileOutputStream(dst))
            ZipOutputStream(cnt).use { zos ->
                for (e in zf.entries().asSequence()) {
                    val n = e.name
                    if (n == "AndroidManifest.xml" || isOldSignature(n)) continue
                    val ne = ZipEntry(n)
                    if (e.method == ZipEntry.STORED) {
                        // Stored entries (resources.arsc) must start on a 4-byte boundary for targetSdk 30+.
                        ne.method = ZipEntry.STORED; ne.size = e.size; ne.compressedSize = e.size; ne.crc = e.crc
                        val pad = ((4 - (cnt.n + 30 + n.toByteArray(Charsets.UTF_8).size + 4) % 4) % 4).toInt()
                        ne.extra = ByteArray(4 + pad).also { it[0] = 0x35; it[1] = 0xD9.toByte(); it[2] = pad.toByte() }
                    }
                    zos.putNextEntry(ne)
                    if (!e.isDirectory) zf.getInputStream(e).use { it.copyTo(zos) }
                    zos.closeEntry()
                }
                val manifest = zf.getInputStream(zf.getEntry("AndroidManifest.xml")).use { it.readBytes() }
                zos.putNextEntry(ZipEntry("AndroidManifest.xml")); zos.write(AxmlPatcher.replaceStrings(manifest, repl)); zos.closeEntry()
                zos.putNextEntry(ZipEntry("assets/gameport_game.json")); zos.write(config); zos.closeEntry()
            }
        }
    }

    private fun sign(inApk: File, outApk: File) {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val now = System.currentTimeMillis()
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
            kpg.initialize(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                    .setKeySize(2048)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .setCertificateSubject(X500Principal("CN=GamePort"))
                    .setCertificateNotBefore(Date(now - 86_400_000L))
                    .setCertificateNotAfter(Date(2_461_449_600_000L)) // 2048-01-01
                    .build()
            )
            kpg.generateKeyPair()
        }
        val key = ks.getKey(ALIAS, null) as PrivateKey
        val cert = ks.getCertificate(ALIAS) as X509Certificate
        val signer = ApkSigner.SignerConfig.Builder("gameport", key, listOf(cert)).build()
        outApk.delete()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(inApk).setOutputApk(outApk)
            .setMinSdkVersion(26)
            .setV1SigningEnabled(false).setV2SigningEnabled(true).setV3SigningEnabled(false)
            .build().sign()
    }
}

/** Minimal Android binary-XML editor: swaps whole strings in the manifest's string pool (indices unchanged). */
object AxmlPatcher {
    private val LE = ByteOrder.LITTLE_ENDIAN

    fun replaceStrings(src: ByteArray, map: Map<String, String>): ByteArray {
        val bb = ByteBuffer.wrap(src).order(LE)
        require(bb.getShort(0).toInt() == 0x0003) { "AndroidManifest.xml is not binary XML" }
        val pool = bb.getShort(2).toInt() and 0xFFFF
        require(bb.getShort(pool).toInt() == 0x0001) { "String pool not found" }
        val hdr = bb.getShort(pool + 2).toInt() and 0xFFFF
        val poolSize = bb.getInt(pool + 4)
        val count = bb.getInt(pool + 8)
        val styles = bb.getInt(pool + 12)
        val flags = bb.getInt(pool + 16)
        val strStart = bb.getInt(pool + 20)
        require(styles == 0) { "Manifest string pool has styled strings (unsupported)" }
        val utf8 = (flags and 0x100) != 0

        val strings = (0 until count).map { i ->
            val off = pool + strStart + bb.getInt(pool + hdr + 4 * i)
            if (utf8) readUtf8(bb, off) else readUtf16(bb, off)
        }
        val data = ByteArrayOutputStream()
        val offsets = IntArray(count)
        strings.forEachIndexed { i, s ->
            offsets[i] = data.size()
            data.write(if (utf8) enc8(map[s] ?: s) else enc16(map[s] ?: s))
        }
        while (data.size() % 4 != 0) data.write(0)

        val newStrStart = hdr + 4 * count
        val head = ByteBuffer.allocate(newStrStart).order(LE)
        head.putShort(0x0001.toShort()); head.putShort(hdr.toShort()); head.putInt(newStrStart + data.size())
        head.putInt(count); head.putInt(0); head.putInt(flags and 1.inv()); head.putInt(newStrStart); head.putInt(0)
        offsets.forEachIndexed { i, o -> head.putInt(hdr + 4 * i, o) }

        val out = ByteArrayOutputStream()
        out.write(src, 0, pool)
        out.write(head.array())
        out.write(data.toByteArray())
        out.write(src, pool + poolSize, src.size - pool - poolSize)
        val res = out.toByteArray()
        ByteBuffer.wrap(res).order(LE).putInt(4, res.size)
        return res
    }

    private fun readUtf16(bb: ByteBuffer, off: Int): String {
        var p = off
        var len = bb.getShort(p).toInt() and 0xFFFF; p += 2
        if ((len and 0x8000) != 0) { len = ((len and 0x7FFF) shl 16) or (bb.getShort(p).toInt() and 0xFFFF); p += 2 }
        val sb = StringBuilder(len)
        for (i in 0 until len) sb.append(bb.getShort(p + 2 * i).toInt().toChar())
        return sb.toString()
    }

    private fun readUtf8(bb: ByteBuffer, off: Int): String {
        var p = off
        var chars = bb.get(p).toInt() and 0xFF; p++
        if ((chars and 0x80) != 0) { chars = ((chars and 0x7F) shl 8) or (bb.get(p).toInt() and 0xFF); p++ }
        var bytes = bb.get(p).toInt() and 0xFF; p++
        if ((bytes and 0x80) != 0) { bytes = ((bytes and 0x7F) shl 8) or (bb.get(p).toInt() and 0xFF); p++ }
        val b = ByteArray(bytes) { bb.get(p + it) }
        return String(b, Charsets.UTF_8)
    }

    private fun enc16(s: String): ByteArray {
        val o = ByteArrayOutputStream()
        fun w16(v: Int) { o.write(v and 0xFF); o.write((v shr 8) and 0xFF) }
        if (s.length > 0x7FFF) { w16((s.length shr 16) or 0x8000); w16(s.length and 0xFFFF) } else w16(s.length)
        s.forEach { w16(it.code) }
        w16(0)
        return o.toByteArray()
    }

    private fun lenBytes(o: ByteArrayOutputStream, n: Int) {
        if (n > 0x7F) { o.write((n shr 8) or 0x80); o.write(n and 0xFF) } else o.write(n)
    }

    private fun enc8(s: String): ByteArray {
        val b = s.toByteArray(Charsets.UTF_8)
        val o = ByteArrayOutputStream()
        lenBytes(o, s.length); lenBytes(o, b.size); o.write(b); o.write(0)
        return o.toByteArray()
    }
}

/** Installs a built APK through Android's package installer (the system shows its normal confirm screen). */
object ApkInstaller {
    const val ACTION = "com.gameport.mobile.INSTALL_RESULT"

    fun install(ctx: Context, apk: File) {
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            FileInputStream(apk).use { ins ->
                s.openWrite("base.apk", 0, apk.length()).use { out ->
                    ins.copyTo(out)
                    s.fsync(out)
                }
            }
            val pending = PendingIntent.getBroadcast(
                ctx, id, Intent(ACTION).setPackage(ctx.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            s.commit(pending.intentSender)
        }
    }
}
