package com.gameport.mobile

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * The runtime pack (Wine + Box64 + Vulkan driver files) is downloaded by the game app on first launch,
 * so the APK itself stays small. Put the address of your hosted runtime .zip in PACK_URL.
 * Empty = nothing configured yet, so the game app skips this step.
 */
object RuntimePack {
    const val PACK_URL = ""

    fun installed(ctx: Context) = File(ctx.filesDir, "runtime/.ok").exists()

    /** Blocks: call from a background thread. */
    fun download(ctx: Context, onProgress: (String) -> Unit) {
        if (PACK_URL.isEmpty()) throw IllegalStateException("No runtime download address is set yet")
        val dir = File(ctx.filesDir, "runtime")
        dir.deleteRecursively(); dir.mkdirs()
        val tmp = File(ctx.cacheDir, "runtime.zip")
        val conn = URL(PACK_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000; conn.readTimeout = 30000
        val total = conn.contentLengthLong
        conn.inputStream.use { ins ->
            FileOutputStream(tmp).use { out ->
                val buf = ByteArray(1 shl 16)
                var done = 0L; var lastMb = -1L; var r: Int
                while (ins.read(buf).also { r = it } != -1) {
                    out.write(buf, 0, r); done += r
                    val mb = done shr 22 // report every 4 MB
                    if (mb != lastMb) { lastMb = mb; onProgress("Downloading runtime… ${done shr 20} MB" + if (total > 0) " of ${total shr 20} MB" else "") }
                }
            }
        }
        onProgress("Unpacking runtime…")
        val base = dir.canonicalPath + File.separator
        ZipInputStream(tmp.inputStream().buffered(1 shl 16)).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val out = File(dir, e.name.replace('\\', '/'))
                if (!out.canonicalPath.startsWith(base)) throw SecurityException("Blocked unsafe path in runtime pack")
                if (e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); FileOutputStream(out).use { zin.copyTo(it, 1 shl 16) } }
                e = zin.nextEntry
            }
        }
        File(dir, ".ok").writeText("1")
        tmp.delete()
    }
}
