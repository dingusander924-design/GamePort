package com.gameport.mobile

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipInputStream

/** A game that was unpacked from a ZIP into GamePort's private storage. */
data class PortedGame(val id: String, val title: String, val dir: String, val exe: String)

object PortedStore {
    private fun prefs(c: Context) = c.getSharedPreferences("gameport_ported", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<PortedGame> {
        val out = mutableListOf<PortedGame>()
        try {
            val arr = JSONArray(prefs(c).getString("games", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(PortedGame(o.getString("id"), o.getString("title"), o.getString("dir"), o.getString("exe")))
            }
        } catch (_: Exception) { out.clear() }
        return out
    }

    fun save(c: Context, list: List<PortedGame>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("dir", it.dir).put("exe", it.exe)) }
        prefs(c).edit().putString("games", arr.toString()).apply()
    }
}

object ZipImporter {
    // Installers, crash reporters and anti-cheat helpers are never the game itself.
    private val skipNames = Regex("unins|uninstall|crash|vcredist|vc_redist|dxsetup|dotnet|redist|prereq|easyanticheat|eac_", RegexOption.IGNORE_CASE)

    /** Unpacks [zip] into private storage. Blocks, so call it from a background thread. */
    fun import(ctx: Context, zip: Uri, onProgress: (String) -> Unit): PortedGame {
        val doc = DocumentFile.fromSingleUri(ctx, zip)
        val title = (doc?.name ?: "Game").substringBeforeLast('.').take(60)
        val zipBytes = doc?.length() ?: 0L
        val id = UUID.randomUUID().toString().take(8)
        val dest = File(ctx.filesDir, "games/$id")
        if (!dest.mkdirs()) throw IllegalStateException("Couldn't create the game folder")
        val needed = zipBytes * 12 / 10
        if (zipBytes > 0 && dest.usableSpace < needed) {
            dest.delete()
            throw IllegalStateException("Not enough free storage (need roughly ${needed / (1024 * 1024)} MB)")
        }
        try {
            var files = 0
            val base = dest.canonicalPath + File.separator
            ctx.contentResolver.openInputStream(zip)?.use { raw ->
                ZipInputStream(raw.buffered(1 shl 16)).use { zin ->
                    var e = zin.nextEntry
                    while (e != null) {
                        val out = File(dest, e.name.replace('\\', '/'))
                        // Zip-slip guard: never write outside the game folder.
                        if (!out.canonicalPath.startsWith(base)) throw SecurityException("Blocked unsafe path in zip: ${e.name}")
                        if (e.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { zin.copyTo(it, 1 shl 16) }
                            files++
                            if (files % 20 == 0) onProgress("Unpacking… $files files")
                        }
                        e = zin.nextEntry
                    }
                }
            } ?: throw IllegalStateException("Couldn't open the zip")
            if (files == 0) throw IllegalStateException("The zip is empty")
            val exe = findExe(dest) ?: throw IllegalStateException("No game .exe found inside this zip")
            onProgress("Done: $files files")
            return PortedGame(id, title, dest.absolutePath, exe.relativeTo(dest).path)
        } catch (t: Throwable) {
            dest.deleteRecursively()
            throw t
        }
    }

    /** Largest non-installer .exe wins (for Unreal that is the real Shipping exe). */
    fun findExe(dir: File): File? = dir.walkTopDown()
        .filter { it.isFile && it.extension.equals("exe", true) && !skipNames.containsMatchIn(it.name) }
        .maxByOrNull { it.length() }
}
