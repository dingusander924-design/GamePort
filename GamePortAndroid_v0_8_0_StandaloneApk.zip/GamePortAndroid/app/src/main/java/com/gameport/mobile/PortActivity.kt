package com.gameport.mobile

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.os.Build
import android.provider.Settings
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream

class PortActivity : Activity() {
    private val bg = Color.rgb(9, 13, 20)
    private val panel = Color.rgb(22, 29, 40)
    private val accent = Color.rgb(64, 185, 255)
    private val muted = Color.rgb(160, 173, 192)
    private val games = mutableListOf<PortedGame>()
    private var statusText = ""
    private var busy = false
    private lateinit var statusView: TextView
    private val forged = HashMap<String, File>()
    private var saveTarget: File? = null

    private val installReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    @Suppress("DEPRECATION")
                    val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                    confirm?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(it) }
                }
                PackageInstaller.STATUS_SUCCESS -> Toast.makeText(c, "Installed. Find it in your app drawer.", Toast.LENGTH_LONG).show()
                else -> Toast.makeText(c, "Install failed: " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE), Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        games.addAll(PortedStore.load(this))
        val f = IntentFilter(ApkInstaller.ACTION)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(installReceiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(installReceiver, f)
        render()
    }

    override fun onDestroy() {
        try { unregisterReceiver(installReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun tv(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, 5, 0, 7)
    }

    private fun btn(s: String, action: () -> Unit) = Button(this).apply {
        text = s; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(30, 75, 108)); setOnClickListener { action() }
    }

    private fun render() {
        val sc = ScrollView(this).apply { setBackgroundColor(bg) }
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 22) }
        sc.addView(v)
        v.addView(tv("PORT A GAME ZIP", 24f, accent, true))
        v.addView(tv("Pick a PC game .zip. GamePort unpacks it into private storage, finds the game exe, and adds it below with a Play button and a home-screen icon.", 14f, muted))
        val rt = GameRuntime.create(this) { }
        v.addView(tv(rt.status, 13f, Color.rgb(255, 190, 80)))
        v.addView(btn("＋ Import game ZIP") { if (!busy) pickZip() })
        statusView = tv(statusText, 13f)
        v.addView(statusView)
        if (games.isEmpty()) v.addView(tv("No ported games yet.", 14f, muted))
        games.forEach { g ->
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(14, 12, 14, 12) }
            c.addView(tv(g.title, 18f, Color.WHITE, true))
            c.addView(tv("Launches: ${g.exe}", 12f, muted))
            c.addView(btn("▶ Play") { startActivity(Intent(this, GameActivity::class.java).putExtra("gameId", g.id)) })
            c.addView(btn("Add icon to home screen") { pin(g) })
            c.addView(btn("Build standalone game APK") { forge(g) })
            forged[g.id]?.let { f ->
                c.addView(btn("Install the built APK") { install(f) })
                c.addView(btn("Save APK file (to share)") { saveTarget = f; saveApk(f) })
            }
            c.addView(btn("Delete") { delete(g) })
            v.addView(c)
            v.addView(View(this), LinearLayout.LayoutParams(1, 18))
        }
        v.addView(btn("← Back") { finish() })
        setContentView(sc)
    }

    private fun pickZip() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }, 201)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 201 && resultCode == RESULT_OK && uri != null) importZip(uri)
        else if (requestCode == 202 && resultCode == RESULT_OK && uri != null) copyApk(uri)
    }

    private fun importZip(uri: Uri) {
        busy = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // big zips take a while: keep the screen on
        statusView.text = "Starting import… keep GamePort open until it finishes."
        Thread {
            try {
                val g = ZipImporter.import(this, uri) { m -> runOnUiThread { statusView.text = m } }
                runOnUiThread {
                    games.add(0, g); PortedStore.save(this, games)
                    busy = false; statusText = "Imported ${g.title}."; render()
                }
            } catch (e: Exception) {
                runOnUiThread { busy = false; statusText = "Import failed: ${e.message}"; render() }
            }
        }.start()
    }

    private fun forge(g: PortedGame) {
        if (busy) return
        busy = true
        statusView.text = "Building standalone APK…"
        Thread {
            try {
                val f = ApkForge.forge(this, g) { m -> runOnUiThread { statusView.text = m } }
                runOnUiThread { forged[g.id] = f; busy = false; statusText = "Built ${f.name} (${f.length() / 1024} KB). Install it or save the file."; render() }
            } catch (e: Throwable) {
                runOnUiThread { busy = false; statusText = "Build failed: ${e.javaClass.simpleName}: ${e.message}"; render() }
            }
        }.start()
    }

    private fun install(f: File) {
        if (!packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow GamePort to install apps, then tap Install again.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        try { ApkInstaller.install(this, f) } catch (e: Exception) { statusView.text = "Install failed: ${e.message}" }
    }

    private fun saveApk(f: File) {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/vnd.android.package-archive"; putExtra(Intent.EXTRA_TITLE, f.name)
        }, 202)
    }

    private fun copyApk(uri: Uri) {
        val f = saveTarget ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(f).use { it.copyTo(out) } }
            Toast.makeText(this, "Saved. You can send this file to friends.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { statusView.text = "Save failed: ${e.message}" }
    }

    private fun delete(g: PortedGame) {
        Thread { File(g.dir).deleteRecursively() }.start()
        games.remove(g)
        PortedStore.save(this, games)
        render()
    }

    private fun pin(g: PortedGame) {
        val sm = getSystemService(ShortcutManager::class.java)
        if (sm == null || !sm.isRequestPinShortcutSupported) {
            Toast.makeText(this, "Your launcher doesn't support home-screen shortcuts.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, GameActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra("gameId", g.id)
        val info = ShortcutInfo.Builder(this, "game_${g.id}")
            .setShortLabel(g.title.take(24)).setIntent(intent).setIcon(letterIcon(g.title)).build()
        sm.requestPinShortcut(info, null)
    }

    private fun letterIcon(t: String): Icon {
        val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.rgb(30, 75, 108))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 110f; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
        c.drawText(t.take(1).uppercase(), 96f, 135f, p)
        return Icon.createWithBitmap(bmp)
    }
}
