package com.gameport.mobile

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File

/** A standalone game APK is GamePort plus an assets/gameport_game.json file. This reads it. */
object GameBoot {
    class Cfg(val title: String, val exe: String)

    /** Null in the normal GamePort app, non-null inside a forged game APK. */
    fun config(ctx: Context): Cfg? = try {
        ctx.assets.open("gameport_game.json").use { s ->
            val o = JSONObject(String(s.readBytes(), Charsets.UTF_8))
            Cfg(o.optString("title", "Game"), o.optString("exe", ""))
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * First launch of a game APK: ask for the player's own game zip once, unpack it into this app's
 * private storage, then start the game. Later launches go straight to the game.
 */
class GameBootActivity : Activity() {
    private lateinit var status: TextView
    private var busy = false
    private var title = "Game"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = GameBoot.config(this) ?: run { finish(); return }
        title = cfg.title
        val existing = PortedStore.load(this).firstOrNull { it.id == "main" }
        val runtimeReady = RuntimePack.installed(this) || RuntimePack.PACK_URL.isEmpty()
        if (existing != null && File(existing.dir, existing.exe).exists() && runtimeReady) { launch(); return }

        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(9, 13, 20)); setPadding(40, 90, 40, 40) }
        v.addView(TextView(this).apply { text = cfg.title; textSize = 24f; setTextColor(Color.rgb(64, 185, 255)); setTypeface(null, Typeface.BOLD) })
        v.addView(TextView(this).apply {
            text = "First launch: choose your copy of the game's ZIP file. It is unpacked once into this app's private storage. Nothing is uploaded anywhere."
            textSize = 14f; setTextColor(Color.rgb(160, 173, 192)); setPadding(0, 16, 0, 24)
        })
        v.addView(Button(this).apply {
            text = "Choose game ZIP"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(30, 75, 108))
            setOnClickListener { if (!busy) pickZip() }
        })
        status = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE); setPadding(0, 20, 0, 0) }
        v.addView(status)
        setContentView(v)
        ensureRuntime()
    }

    private fun ensureRuntime() {
        if (RuntimePack.installed(this) || RuntimePack.PACK_URL.isEmpty()) return
        busy = true
        status.text = "Getting ready… downloading what the game needs."
        Thread {
            try {
                RuntimePack.download(this) { m -> runOnUiThread { status.text = m } }
                runOnUiThread {
                    busy = false
                    val have = PortedStore.load(this).firstOrNull { it.id == "main" }
                    if (have != null && File(have.dir, have.exe).exists()) { launch() } else { status.text = "Ready. Choose your game ZIP." }
                }
            } catch (e: Exception) {
                runOnUiThread { busy = false; status.text = "Download failed: ${e.message}" }
            }
        }.start()
    }

    private fun launch() {
        startActivity(Intent(this, GameActivity::class.java).putExtra("gameId", "main"))
        finish()
    }

    private fun pickZip() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }, 301)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != 301 || resultCode != RESULT_OK) return
        busy = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status.text = "Starting… keep this screen open until it finishes."
        Thread {
            try {
                val g = ZipImporter.import(this, uri) { m -> runOnUiThread { status.text = m } }
                PortedStore.save(this, listOf(g.copy(id = "main", title = title)))
                runOnUiThread { launch() }
            } catch (e: Exception) {
                runOnUiThread { busy = false; status.text = "Failed: ${e.message}" }
            }
        }.start()
    }
}
