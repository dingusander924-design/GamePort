import unittest
from pathlib import Path
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]

class GithubApkWorkflowTests(unittest.TestCase):
    def test_workflow_yaml_loads(self):
        workflow = yaml.safe_load((ROOT / '.github/workflows/build-apk.yml').read_text())
        self.assertIn('jobs', workflow)
        self.assertIn('debug-build', workflow['jobs'])
        self.assertIn('release-build', workflow['jobs'])

    def test_main_package_id_is_stable_and_shared(self):
        gradle = (ROOT / 'app/build.gradle').read_text()
        self.assertRegex(gradle, r'applicationId\s+[\'\"]com\.gameport\.mobile[\'\"]')
        self.assertRegex(gradle, r'namespace\s+[\'\"]com\.gameport\.mobile[\'\"]')

    def test_ci_checks_package_and_version_and_has_release_signing_secrets(self):
        workflow = (ROOT / '.github/workflows/build-apk.yml').read_text()
        for needle in ["gradle-version: '8.9'", "platforms;android-35", "build-tools;34.0.0",
                      "com.gameport.mobile", "1.0.1-ci", "GAMEPORT_KEYSTORE_BASE64",
                      "GAMEPORT_KEYSTORE_PASSWORD", "GAMEPORT_KEY_ALIAS", "GAMEPORT_KEY_PASSWORD",
                      "keytool -list", "available=true"]:
            self.assertIn(needle, workflow)

    def test_versioncode_tracks_actions_run_number(self):
        gradle = (ROOT / 'app/build.gradle').read_text()
        self.assertIn("GITHUB_RUN_NUMBER", gradle)
        self.assertIn("1000 + runNo", gradle)

if __name__ == '__main__':
    unittest.main()
