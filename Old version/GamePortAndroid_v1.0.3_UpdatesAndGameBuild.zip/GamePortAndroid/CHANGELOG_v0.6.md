# GamePort v0.6 — Library Persistence & Readiness Workbench

## Added
- Imported game library and scan metadata persist across app restarts via SharedPreferences.
- Touch designer preset, scale, and opacity persist automatically.
- Remove imported entry action, with library persistence updated.
- Port assessment includes a heuristic readiness score and explanatory text. This score is a rough inventory indicator, not a prediction that a game will port.
- Text reports are versioned as v0.6.
- Android app version metadata bumped to 0.6.0 / versionCode 6.

## Known limitations
- Project is still a diagnostics/workbench prototype, not a Windows EXE-to-APK converter.
- Touch controls are configurable profile metadata, not active input injection.
- No native engine APK export/build/sign pipeline is integrated.
- Android build and runtime testing were not performed: Android SDK and Gradle are unavailable in the current environment.
