# GamePort 1.0.3

- Buttons and messages no longer say "Winlator": "Export build package", "Export game ZIP", and the home button is now "Runtime setup". (The setup page itself still names Winlator, because it tells people which separate app to install.)
- No other changes from 1.0.2.
