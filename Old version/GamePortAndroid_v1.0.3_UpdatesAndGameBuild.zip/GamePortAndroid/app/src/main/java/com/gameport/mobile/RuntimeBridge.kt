package com.gameport.mobile

import android.content.Context
import android.view.KeyEvent
import android.view.Surface

/** Everything the touch layer can send to a running game. Key codes are Android KeyEvent codes. */
interface InputSink {
    fun key(code: Int, down: Boolean)
    fun mouseMove(dx: Float, dy: Float)
    fun mouseButton(button: Int, down: Boolean) // 0 = left, 1 = right
}

/**
 * The piece that actually runs a Windows game (Wine + Box64 + Vulkan driver).
 * Implement this with a Winlator-style runtime and return it from [GameRuntime.create].
 * start() must launch game.exe from game.dir and render into [surface].
 * Keep every in-game graphics/FPS/settings menu untouched: the game runs as-is.
 */
interface RuntimeBridge : InputSink {
    val available: Boolean
    val status: String
    fun start(game: PortedGame, surface: Surface)
    fun stop()
}

object GameRuntime {
    fun create(ctx: Context, log: (String) -> Unit): RuntimeBridge = NoRuntime(log)
}

/** Placeholder until a real runtime is bundled. Shows touch events so controls can be tested. */
class NoRuntime(private val log: (String) -> Unit) : RuntimeBridge {
    override val available = false
    override val status = "Runtime not installed: the game can't launch yet. Touch controls are live (events show here)."
    override fun start(game: PortedGame, surface: Surface) {}
    override fun stop() {}
    override fun key(code: Int, down: Boolean) = log("KEY ${KeyEvent.keyCodeToString(code)} ${if (down) "down" else "up"}")
    override fun mouseMove(dx: Float, dy: Float) = log("LOOK dx=${dx.toInt()} dy=${dy.toInt()}")
    override fun mouseButton(button: Int, down: Boolean) = log("MOUSE ${if (button == 0) "left" else "right"} ${if (down) "down" else "up"}")
}
