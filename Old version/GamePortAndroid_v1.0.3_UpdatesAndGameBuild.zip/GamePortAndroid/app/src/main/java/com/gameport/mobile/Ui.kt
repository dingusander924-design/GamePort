package com.gameport.mobile

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

/** Shared look for every GamePort screen: deep navy, blue and green accents from the logo, rounded cards. */
object Ui {
    val BG = Color.rgb(6, 10, 18)
    val CARD = Color.rgb(14, 21, 33)
    val STROKE = Color.rgb(30, 44, 66)
    val ACCENT = Color.rgb(46, 166, 255)
    val GREEN = Color.rgb(118, 214, 66)
    val TEXT = Color.rgb(234, 241, 250)
    val MUTED = Color.rgb(143, 160, 184)
    val WARN = Color.rgb(255, 190, 80)
    val DANGER = Color.rgb(255, 107, 107)

    const val STYLE_PRIMARY = 0
    const val STYLE_SECONDARY = 1
    const val STYLE_DANGER = 2

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(c: Context, fill: Int, radiusDp: Float, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = radiusDp * c.resources.displayMetrics.density
        if (stroke != 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    /** Full-width layout params with a top margin in dp. */
    fun lp(c: Context, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(c, top)
        return p
    }

    fun lpWrap(c: Context, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(c, top)
        return p
    }

    fun text(c: Context, s: String, sizeSp: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.setLineSpacing(0f, 1.12f)
        return t
    }

    fun button(c: Context, label: String, style: Int = STYLE_SECONDARY, onClick: () -> Unit): Button {
        val fill: Int
        val fg: Int
        val stroke: Int
        when (style) {
            STYLE_PRIMARY -> { fill = ACCENT; fg = Color.rgb(4, 14, 28); stroke = 0 }
            STYLE_DANGER -> { fill = Color.TRANSPARENT; fg = DANGER; stroke = Color.argb(120, 255, 107, 107) }
            else -> { fill = Color.rgb(24, 36, 56); fg = TEXT; stroke = STROKE }
        }
        val b = Button(c)
        b.text = label
        b.setAllCaps(false)
        b.setTextColor(fg)
        b.textSize = 15f
        b.setTypeface(null, Typeface.BOLD)
        b.stateListAnimator = null
        b.minHeight = dp(c, 50)
        b.minimumHeight = dp(c, 50)
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10))
        b.background = RippleDrawable(
            ColorStateList.valueOf(Color.argb(70, 255, 255, 255)),
            rounded(c, fill, 14f, stroke),
            rounded(c, Color.WHITE, 14f)
        )
        b.setOnClickListener { onClick() }
        return b
    }

    fun card(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = rounded(c, CARD, 18f, STROKE)
        l.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16))
        return l
    }

    fun chip(c: Context, s: String, color: Int): TextView {
        val t = text(c, s, 12f, color, true)
        t.setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6))
        t.background = rounded(c, Color.argb(40, Color.red(color), Color.green(color), Color.blue(color)), 20f)
        return t
    }

    fun tile(c: Context, title: String): TextView {
        val t = text(c, title.trim().take(1).uppercase().ifEmpty { "?" }, 22f, TEXT, true)
        t.gravity = Gravity.CENTER
        t.background = rounded(c, Color.rgb(24, 70, 120), 14f)
        t.layoutParams = LinearLayout.LayoutParams(dp(c, 52), dp(c, 52))
        return t
    }

    fun progress(c: Context): ProgressBar {
        val p = ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal)
        p.isIndeterminate = true
        p.indeterminateTintList = ColorStateList.valueOf(ACCENT)
        return p
    }

    fun header(c: Context, title: String, subtitle: String): LinearLayout {
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(c)
        logo.setImageResource(R.drawable.gameport_logo)
        logo.layoutParams = LinearLayout.LayoutParams(dp(c, 60), dp(c, 60))
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(c, title, 24f, TEXT, true))
        col.addView(text(c, subtitle, 12f, MUTED))
        val colParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        colParams.leftMargin = dp(c, 14)
        row.addView(logo)
        row.addView(col, colParams)
        return row
    }

    fun page(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(c, 18), dp(c, 22), dp(c, 18), dp(c, 28))
        return l
    }

    /** Scrolling screen that keeps content clear of the status and navigation bars. */
    @Suppress("DEPRECATION")
    fun scroll(a: Activity, content: LinearLayout): ScrollView {
        val sv = ScrollView(a)
        sv.setBackgroundColor(BG)
        sv.clipToPadding = false
        sv.addView(content)
        sv.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins
        }
        return sv
    }
}
