package com.gameport.mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

/**
 * FPS-style touch controller: left stick = WASD, right side drag = mouse look, buttons = mouse/keys.
 * Multitouch: each finger gets its own role, so you can move, look and fire at once.
 */
class TouchOverlay(ctx: Context, private val sink: InputSink, scalePct: Int, opacityPct: Int) : View(ctx) {
    private class Btn(val label: String, val fx: Float, val fy: Float, val rDp: Float, val key: Int = -1, val mouse: Int = -1)

    private val d = resources.displayMetrics.density
    private val s = scalePct.coerceIn(50, 150) / 100f
    private val a = opacityPct.coerceIn(10, 100) * 255 / 100

    private val btns = listOf(
        Btn("FIRE", .90f, .58f, 46f, mouse = 0),
        Btn("AIM", .80f, .78f, 36f, mouse = 1),
        Btn("JUMP", .92f, .83f, 34f, key = KeyEvent.KEYCODE_SPACE),
        Btn("RELOAD", .79f, .40f, 30f, key = KeyEvent.KEYCODE_R),
        Btn("CROUCH", .68f, .88f, 30f, key = KeyEvent.KEYCODE_CTRL_LEFT),
        Btn("USE", .68f, .68f, 28f, key = KeyEvent.KEYCODE_E),
        Btn("MENU", .05f, .10f, 26f, key = KeyEvent.KEYCODE_ESCAPE)
    )

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f; alpha = a }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; alpha = a }

    private val roles = HashMap<Int, Int>()          // pointerId -> role (button index, ROLE_STICK or ROLE_LOOK)
    private val lastX = HashMap<Int, Float>()
    private val lastY = HashMap<Int, Float>()
    private val held = HashSet<Int>()
    private var cx = 0f; private var cy = 0f; private var kx = 0f; private var ky = 0f
    private var stickOn = false
    private val stickR get() = 60f * d * s
    private val lookGain = 1.6f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> roles.keys.toList().forEach { up(it) }
        }
        invalidate()
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        val hit = btns.indexOfFirst { b ->
            val bx = b.fx * width; val by = b.fy * height; val r = b.rDp * d * s
            (x - bx) * (x - bx) + (y - by) * (y - by) <= r * r
        }
        when {
            hit >= 0 -> { roles[id] = hit; press(btns[hit], true) }
            x < width * 0.45f -> { roles[id] = ROLE_STICK; stickOn = true; cx = x; cy = y; kx = x; ky = y }
            else -> { roles[id] = ROLE_LOOK; lastX[id] = x; lastY[id] = y }
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        when (roles[id]) {
            ROLE_STICK -> {
                var dx = x - cx; var dy = y - cy
                val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (len > stickR) { dx *= stickR / len; dy *= stickR / len }
                kx = cx + dx; ky = cy + dy
                val t = stickR * 0.3f
                setKey(KeyEvent.KEYCODE_W, dy < -t); setKey(KeyEvent.KEYCODE_S, dy > t)
                setKey(KeyEvent.KEYCODE_A, dx < -t); setKey(KeyEvent.KEYCODE_D, dx > t)
            }
            ROLE_LOOK -> {
                val lx = lastX[id] ?: x; val ly = lastY[id] ?: y
                sink.mouseMove((x - lx) * lookGain, (y - ly) * lookGain)
                lastX[id] = x; lastY[id] = y
            }
        }
    }

    private fun up(id: Int) {
        val r = roles.remove(id) ?: return
        if (r == ROLE_STICK) {
            stickOn = false
            listOf(KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D).forEach { setKey(it, false) }
        } else if (r >= 0) {
            press(btns[r], false)
        }
        lastX.remove(id); lastY.remove(id)
    }

    private fun press(b: Btn, down: Boolean) {
        if (b.key >= 0) sink.key(b.key, down)
        if (b.mouse >= 0) sink.mouseButton(b.mouse, down)
    }

    private fun setKey(code: Int, on: Boolean) {
        if (on && held.add(code)) sink.key(code, true)
        else if (!on && held.remove(code)) sink.key(code, false)
    }

    override fun onDraw(c: Canvas) {
        btns.forEachIndexed { i, b ->
            val bx = b.fx * width; val by = b.fy * height; val r = b.rDp * d * s
            fill.alpha = if (roles.containsValue(i)) a else a / 3
            c.drawCircle(bx, by, r, fill)
            c.drawCircle(bx, by, r, stroke)
            text.textSize = r * 0.42f
            c.drawText(b.label, bx, by + text.textSize / 3, text)
        }
        val bx = if (stickOn) cx else width * 0.14f
        val by = if (stickOn) cy else height * 0.72f
        c.drawCircle(bx, by, stickR, stroke)
        fill.alpha = a / 2
        c.drawCircle(if (stickOn) kx else bx, if (stickOn) ky else by, stickR * 0.4f, fill)
    }

    private companion object {
        const val ROLE_STICK = -1
        const val ROLE_LOOK = -2
    }
}
