package com.gameport.mobile

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipEntry
import java.util.zip.CRC32
import java.util.zip.ZipOutputStream
import java.util.zip.ZipFile
import org.json.JSONObject

class PortActivity : Activity() {
    private val games = mutableListOf<PortedGame>()
    private var statusText = ""
    private var busy = false
    private lateinit var statusView: TextView
    private var pendingZipGame: PortedGame? = null
    private var pendingBuildPackageGame: PortedGame? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        games.addAll(PortedStore.load(this))
        render()
    }

    private fun render() {
        val page = Ui.page(this)
        page.addView(Ui.header(this, "Port a game ZIP", "Import games and export build packages"))

        val rt = GameRuntime.create(this) { }
        val chip = if (rt.available) Ui.chip(this, "Runtime ready", Ui.GREEN) else Ui.chip(this, "Test surface only", Ui.WARN)
        page.addView(chip, Ui.lpWrap(this, 16))
        page.addView(Ui.text(this, "Import a PC game ZIP. Test controls are a sandbox only. Export a build package to prepare a standalone game build; GamePort cannot compile that APK on-device yet.", 14f, Ui.MUTED), Ui.lp(this, 12))
        page.addView(Ui.button(this, "＋  Import game ZIP", Ui.STYLE_PRIMARY) { if (!busy) pickZip() }, Ui.lp(this, 16))

        statusView = Ui.text(this, statusText, 13f, Ui.TEXT)
        page.addView(statusView, Ui.lp(this, 10))
        if (busy) page.addView(Ui.progress(this), Ui.lp(this, 6))

        if (games.isEmpty()) {
            val empty = Ui.card(this)
            empty.addView(Ui.text(this, "No games yet", 17f, Ui.TEXT, true))
            empty.addView(Ui.text(this, "Import a game ZIP above. Test its touch layout or export a build package.", 13f, Ui.MUTED), Ui.lp(this, 6))
            page.addView(empty, Ui.lp(this, 18))
        }
        games.forEach { g -> page.addView(gameCard(g), Ui.lp(this, 16)) }

        page.addView(Ui.button(this, "←  Back", Ui.STYLE_SECONDARY) { finish() }, Ui.lp(this, 24))
        setContentView(Ui.scroll(this, page))
    }

    private fun gameCard(g: PortedGame): LinearLayout {
        val c = Ui.card(this)
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.tile(this, g.title))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.text(this, g.title, 17f, Ui.TEXT, true))
        col.addView(Ui.text(this, g.exe, 12f, Ui.MUTED))
        val colParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        colParams.leftMargin = Ui.dp(this, 12)
        top.addView(col, colParams)
        c.addView(top)

        c.addView(Ui.button(this, "▶  Test controls", Ui.STYLE_PRIMARY) {
            startActivity(Intent(this, GameActivity::class.java).putExtra("gameId", g.id))
        }, Ui.lp(this, 14))
        c.addView(Ui.button(this, "Export game ZIP", Ui.STYLE_SECONDARY) { if (!busy) saveGameZip(g) }, Ui.lp(this, 8))
        c.addView(Ui.button(this, "Export build package", Ui.STYLE_SECONDARY) { if (!busy) exportBuildPackage(g) }, Ui.lp(this, 8))
        c.addView(Ui.button(this, "Add icon to home screen", Ui.STYLE_SECONDARY) { pin(g) }, Ui.lp(this, 8))
        c.addView(Ui.button(this, "Delete", Ui.STYLE_DANGER) { confirmDelete(g) }, Ui.lp(this, 8))
        return c
    }

    private fun startBusy(msg: String) {
        busy = true
        statusText = msg
        render()
    }

    private fun pickZip() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }, 201)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 201 && resultCode == RESULT_OK && uri != null) importZip(uri)
        else if (requestCode == 203 && resultCode == RESULT_OK && uri != null) zipGameTo(uri, pendingZipGame)
        else if (requestCode == 203) pendingZipGame = null
        else if (requestCode == 204 && resultCode == RESULT_OK && uri != null) buildPackageTo(uri, pendingBuildPackageGame)
        else if (requestCode == 204) pendingBuildPackageGame = null
    }




    private fun saveGameZip(g: PortedGame) {
        pendingZipGame = g
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "${g.title.replace(Regex("[^A-Za-z0-9._-]"), "_")}.zip")
        }, 203)
    }


    private fun zipGameTo(uri: Uri, g: PortedGame?) {
        val game = g ?: return
        pendingZipGame = null
        startBusy("Exporting ${game.title} ZIP…")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            try {
                val root = File(game.dir).canonicalFile
                if (!root.exists() || !root.isDirectory) throw IllegalStateException("Game folder is missing")
                val base = root.path + File.separator
                val files = root.walkTopDown().filter { it.isFile }.toList()
                if (files.isEmpty()) throw IllegalStateException("Game folder contains no files")
                var count = 0
                val raw = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Couldn't open selected save destination")
                raw.use { stream ->
                    ZipOutputStream(stream.buffered(1 shl 16)).use { zip ->
                        files.forEach { file ->
                            val canon = file.canonicalPath
                            if (!canon.startsWith(base)) throw SecurityException("File escaped game directory")
                            val rel = file.relativeTo(root).path.replace(File.separatorChar, '/')
                            zip.putNextEntry(ZipEntry(rel))
                            FileInputStream(file).use { input -> input.copyTo(zip, 1 shl 16) }
                            zip.closeEntry(); count++
                            if (count % 30 == 0) runOnUiThread { statusView.text = "Exporting ZIP… $count files" }
                        }
                    }
                }
                runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); busy = false; statusText = "Exported $count files to your ZIP."; render() }
            } catch (e: Exception) {
                runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); busy = false; statusText = "ZIP export failed: ${e.message}"; render() }
            }
        }.start()
    }


    private fun importZip(uri: Uri) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // big zips take a while: keep the screen on
        startBusy("Starting import… keep GamePort open until it finishes.")
        Thread {
            try {
                val g = ZipImporter.import(this, uri) { m -> runOnUiThread { statusView.text = m } }
                runOnUiThread {
                    games.add(0, g); PortedStore.save(this, games)
                    busy = false; statusText = "Imported ${g.title}."; render()
                }
            } catch (e: Exception) {
                runOnUiThread { busy = false; statusText = "Import failed: ${e.message}"; render() }
            }
        }.start()
    }


    private fun exportBuildPackage(g: PortedGame) {
        pendingBuildPackageGame = g
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "${g.title.replace(Regex("[^A-Za-z0-9._-]"), "_")}_GamePortBuildPackage.zip")
        }, 204)
    }


    private fun buildPackageTo(uri: Uri, g: PortedGame?) {
        val game = g ?: return
        pendingBuildPackageGame = null
        startBusy("Creating build package…")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            var tempPayload: File? = null
            var tempPackage: File? = null
            try {
                val root = File(game.dir).canonicalFile
                if (!root.isDirectory) throw IllegalStateException("Imported game folder is missing")
                val base = root.path + File.separator
                val exe = File(root, game.exe).canonicalFile
                if (!exe.path.startsWith(base) || !exe.isFile || !exe.name.endsWith(".exe", true)) throw SecurityException("Game EXE path is invalid")
                val files = root.walkTopDown().filter { it.isFile }.toList()
                if (files.isEmpty()) throw IllegalStateException("Game folder has no files")
                if (files.size > 200000) throw IllegalStateException("Game folder exceeds 200,000 files")
                val unpackedBytes = files.sumOf { it.length() }
                if (unpackedBytes > 10L * 1024L * 1024L * 1024L) throw IllegalStateException("Game files exceed 10 GB uncompressed limit")
                val payloadFile = File(cacheDir, "gameport_payload_${game.id}.zip")
                tempPayload = payloadFile
                ZipOutputStream(payloadFile.outputStream().buffered(1 shl 16)).use { payloadZip ->
                    var fileCount = 0
                    files.forEach { file ->
                        if (!file.canonicalPath.startsWith(base)) throw SecurityException("File escaped imported game folder")
                        val relative = file.relativeTo(root).path.replace(File.separatorChar, '/')
                        if (relative.isEmpty() || relative.startsWith("/") || relative.contains("../") || relative.contains(':')) throw SecurityException("Unsafe file path")
                        payloadZip.putNextEntry(ZipEntry(relative))
                        FileInputStream(file).use { it.copyTo(payloadZip, 1 shl 16) }
                        payloadZip.closeEntry()
                        fileCount++
                        if (fileCount % 50 == 0) runOnUiThread { statusView.text = "Packaging files… $fileCount/${files.size}" }
                    }
                }
                if (payloadFile.length() > 1_900_000_000L) throw IllegalStateException("Compressed payload exceeds the APK asset limit")
                val manifest = JSONObject()
                    .put("schemaVersion", 1)
                    .put("title", game.title.take(80))
                    .put("executable", game.exe.replace('\\', '/').replace(File.separatorChar, '/'))
                val packageFile = File(cacheDir, "gameport_buildpackage_${game.id}.zip")
                tempPackage = packageFile
                ZipOutputStream(packageFile.outputStream().buffered(1 shl 16)).use { packageZip ->
                    packageZip.putNextEntry(ZipEntry("gameport/game_manifest.json"))
                    packageZip.write((manifest.toString(2) + "\n").toByteArray(Charsets.UTF_8))
                    packageZip.closeEntry()
                    val payloadCrc = CRC32().apply { FileInputStream(payloadFile).use { input ->
                        val buf = ByteArray(1 shl 16); var n: Int
                        while (input.read(buf).also { n = it } != -1) update(buf, 0, n)
                    } }.value
                    val payloadEntry = ZipEntry("gameport/game_payload.zip").apply {
                        method = ZipEntry.STORED; size = payloadFile.length(); compressedSize = payloadFile.length(); crc = payloadCrc
                    }
                    packageZip.putNextEntry(payloadEntry)
                    FileInputStream(payloadFile).use { it.copyTo(packageZip, 1 shl 16) }
                    packageZip.closeEntry()
                    val iconSizes = listOf("mdpi" to 48, "hdpi" to 72, "xhdpi" to 96, "xxhdpi" to 144, "xxxhdpi" to 192)
                    iconSizes.forEach { (bucket, size) -> writeIconAsset(packageZip, "gameport/icons/ic_launcher-$bucket.png", game.title, size) }
                    writeIconAsset(packageZip, "gameport/icons/ic_launcher-foreground.png", game.title, 108)
                }
                // Read every entry to EOF before copying to the user-selected SAF destination;
                // ZipFile verifies CRCs while streams are consumed.
                ZipFile(packageFile).use { verified ->
                    val required = listOf("gameport/game_manifest.json", "gameport/game_payload.zip", "gameport/icons/ic_launcher-foreground.png")
                    required.forEach { if (verified.getEntry(it) == null) throw IllegalStateException("Build package missing $it") }
                    verified.entries().asSequence().forEach { entry ->
                        verified.getInputStream(entry).use { input ->
                            val buffer = ByteArray(1 shl 16); while (input.read(buffer) != -1) { }
                        }
                    }
                }
                val raw = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Cannot open selected destination")
                raw.use { output -> FileInputStream(packageFile).use { it.copyTo(output, 1 shl 16) } }
                runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); busy = false; statusText = "Build package exported and CRC-checked. Upload it to your GitHub repo, then run the build workflow with its file name."; render() }
            } catch (e: Exception) {
                runOnUiThread { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); busy = false; statusText = "Build package failed: ${e.message}"; render() }
            } finally { tempPayload?.delete(); tempPackage?.delete() }
        }.start()
    }


    private fun writeIconAsset(zip: ZipOutputStream, entryName: String, title: String, size: Int) {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(0, 220, 255); style = Paint.Style.STROKE; strokeWidth = size * 0.055f
        }
        canvas.drawCircle(size / 2f, size / 2f, size * 0.36f, accent)
        val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = size * 0.58f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val first = title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "G"
        canvas.drawText(first, size / 2f, size * 0.69f, letter)
        val output = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        bitmap.recycle()
        zip.putNextEntry(ZipEntry(entryName))
        zip.write(output.toByteArray())
        zip.closeEntry()
    }

    private fun confirmDelete(g: PortedGame) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${g.title}?")
            .setMessage("This removes the unpacked game files from this phone.")
            .setPositiveButton("Delete") { _, _ -> delete(g) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun delete(g: PortedGame) {
        Thread { File(g.dir).deleteRecursively() }.start()
        games.remove(g)
        PortedStore.save(this, games)
        render()
    }

    private fun pin(g: PortedGame) {
        val sm = getSystemService(ShortcutManager::class.java)
        if (sm == null || !sm.isRequestPinShortcutSupported) {
            Toast.makeText(this, "Your launcher doesn't support home-screen shortcuts.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, GameActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra("gameId", g.id)
        val info = ShortcutInfo.Builder(this, "game_${g.id}")
            .setShortLabel(g.title.take(24)).setIntent(intent).setIcon(letterIcon(g.title)).build()
        sm.requestPinShortcut(info, null)
    }

    private fun letterIcon(t: String): Icon {
        val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.rgb(24, 70, 120))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 110f; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
        c.drawText(t.take(1).uppercase(), 96f, 135f, p)
        return Icon.createWithBitmap(bmp)
    }
}
