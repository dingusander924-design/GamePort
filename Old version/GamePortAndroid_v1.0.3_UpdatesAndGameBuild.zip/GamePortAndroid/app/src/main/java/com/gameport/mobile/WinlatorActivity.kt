package com.gameport.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** Winlator is a separate emulator app; GamePort provides an official-link/setup bridge, not embedded Wine/Box64. */
class WinlatorActivity : Activity() {
    private val officialReleases = "https://github.com/brunodev85/winlator/releases"
    private val v9Release = "https://github.com/brunodev85/winlator/releases/tag/v9.0.0"
    private val sourceZip = "https://github.com/brunodev85/winlator/archive/refs/heads/main.zip"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = Ui.page(this)
        page.addView(Ui.header(this, "Winlator Companion", "Windows games on Android — external runtime setup"))
        val card = Ui.card(this)
        card.addView(Ui.text(this, "Winlator runs Windows apps using Wine, Box86/Box64 and graphics translation. It is installed separately; GamePort does not embed or clone its engine.", 14f, Ui.MUTED))
        card.addView(Ui.button(this, "Open official Winlator releases", Ui.STYLE_PRIMARY) { open(officialReleases) }, Ui.lp(this, 14))
        card.addView(Ui.button(this, "Open Winlator 9.0 release", Ui.STYLE_SECONDARY) { open(v9Release) }, Ui.lp(this, 8))
        card.addView(Ui.button(this, "Launch Winlator (if installed)", Ui.STYLE_SECONDARY) { launchWinlator() }, Ui.lp(this, 8))
        page.addView(card, Ui.lp(this, 16))

        val steps = Ui.card(this)
        steps.addView(Ui.text(this, "SETUP", 16f, Ui.TEXT, true))
        steps.addView(Ui.text(this, """1. Open the official release page and download the APK.
2. Install Winlator and open it once; allow its first-run setup to finish.
3. In Winlator, create a container and set its graphics/CPU options for your phone.
4. Use GamePort’s Export game ZIP button to create a user-accessible game archive.
5. Open that ZIP from Winlator’s file manager and extract/import it into the container.
6. Create a Winlator shortcut to the game executable and test it there.""", 13f, Ui.MUTED), Ui.lp(this, 8))
        steps.addView(Ui.text(this, "The Winlator repository ZIP is source code for developers—not the Wine/Box64 runtime. The official release page is the safest way to choose the APK. Release 9.0 is an older version; prefer a supported current release unless you specifically need v9.", 13f, Ui.WARN), Ui.lp(this, 10))
        steps.addView(Ui.button(this, "Optional: Open Winlator source ZIP", Ui.STYLE_SECONDARY) { open(sourceZip) }, Ui.lp(this, 10))
        page.addView(steps, Ui.lp(this, 12))
        page.addView(Ui.button(this, "← Back", Ui.STYLE_SECONDARY) { finish() }, Ui.lp(this, 18))
        setContentView(Ui.scroll(this, page))
    }


    private fun open(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "Couldn't open the link. Copy it from the project README.", Toast.LENGTH_LONG).show() }
    }


    private fun launchWinlator() {
        val launch = packageManager.getLaunchIntentForPackage("com.winlator")
        if (launch == null) {
            Toast.makeText(this, "Winlator isn't installed yet. Use the official releases link first.", Toast.LENGTH_LONG).show()
            open(officialReleases)
        } else startActivity(launch)
    }
}
