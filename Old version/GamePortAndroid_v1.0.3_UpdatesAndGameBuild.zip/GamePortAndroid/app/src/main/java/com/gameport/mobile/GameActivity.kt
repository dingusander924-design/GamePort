package com.gameport.mobile

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

/** Launched from the Play button or a home-screen shortcut: extra "gameId" picks the game. */
class GameActivity : Activity(), SurfaceHolder.Callback {
    private var runtime: RuntimeBridge? = null
    private var game: PortedGame? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val g = PortedStore.load(this).firstOrNull { it.id == intent.getStringExtra("gameId") }
        if (g == null) {
            Toast.makeText(this, "Game not found. It may have been deleted.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        game = g
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideBars()

        // Same saved size/opacity as the Touch Layout Designer.
        val prefs = getSharedPreferences("gameport_v06", MODE_PRIVATE)
        val log = TextView(this).apply {
            setTextColor(Color.rgb(255, 190, 80)); textSize = 12f; setPadding(24, 12, 24, 0)
        }
        val rt = GameRuntime.create(this) { msg -> log.text = msg }
        runtime = rt
        log.text = rt.status

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val sv = SurfaceView(this)
        sv.holder.addCallback(this)
        root.addView(sv)
        root.addView(log, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root.addView(TouchOverlay(this, rt, prefs.getInt("scale", 100), prefs.getInt("opacity", 75)))
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun surfaceCreated(holder: SurfaceHolder) { game?.let { runtime?.start(it, holder.surface) } }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) { runtime?.stop() }
    override fun onDestroy() { runtime?.stop(); super.onDestroy() }
}
