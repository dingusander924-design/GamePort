# v0.6.1 — Update-ready packaging revision

- Kept application ID `com.gameport.mobile` unchanged for Android update compatibility.
- Incremented `versionCode` to 2 and `versionName` to 0.6.1.
- Added a phone-only MobileStudio build/install guide.
- **This revision is source only:** APK build and device update have not been tested here.
- In-place updates require the same APK signing certificate as the previously installed build.
