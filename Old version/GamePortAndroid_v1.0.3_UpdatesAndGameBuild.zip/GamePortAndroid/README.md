# GamePort Android — 1.0.0 Build Pipeline Preview

GamePort is a Windows-game packaging workbench. This version corrects the previous misleading APK-forge behavior: the old forge cloned the GamePort APK and did **not** contain Wine/Box64, so it was not a standalone Windows-game APK. That fake clone-APK route and its embedded signer have been removed.


## What works in this source revision

- Import a game ZIP into GamePort's private storage and identify an EXE.
- Saved game library and deletion.
- Touch-control layout test surface. It displays/logs control events but is not connected to a Windows runtime.
- Export the imported game as a normal ZIP for use in Winlator.
- **Export Winlator build package**: creates a ZIP containing `gameport/game_manifest.json` and a nested `gameport/game_payload.zip`, which can be fed to the builder script.
- `tools/gameport_winlator_fork.py`: takes an official/source Winlator ZIP and a GamePort build package, generates a customized Winlator Android source project with a per-game package ID, game title, bundled payload, generated letter icon, and first-run direct-launch bootstrap.
- Generator validation: path traversal rejection, duplicate archive path rejection, executable existence validation, payload-size/file-count caps, stable package IDs, and APK build preflight.


## What is not verified / not yet a stable 1.0 release

- GamePort itself does not run Gradle or compile a Winlator APK on the phone.
- No actual game APK was generated in this environment.
- The customized Winlator project has not been Android-compiled, installed, or device-tested.
- Windows-game compatibility, graphics, controls, audio, game-specific setup, and first-run extraction remain unverified.
- Anti-cheat is not bypassed. Games requiring EAC or other anti-cheat may not work, especially online.

This is **1.0.0 Build Pipeline Preview**, not an officially verified stable release. The first genuine APK build/install test is still required before calling it stable.


## Phone workflow

1. Import your own game ZIP in GamePort.
2. Tap **Export Winlator build package** and save the resulting ZIP.
3. Put this GamePort source ZIP, the Winlator source ZIP, and the exported game package somewhere accessible to a Python environment (for example, Termux if installed).
4. Run the builder with Python 3.10+:

```sh
python3 tools/gameport_winlator_fork.py \
  --winlator-source /path/to/winlator-app-main.zip \
  --game-package /path/to/MyGame_GamePortBuildPackage.zip \
  --output /path/to/MyGame_WinlatorProject.zip
```

5. The generated project ZIP contains the modified Winlator source and the game payload under `app/src/main/assets/gameport/`. Extract it and open the `WinlatorGameProject` folder in an Android build IDE that supports its native C/C++ toolchain.
6. Build `assembleDebug` with a local system Gradle and `--offline` if the dependencies are already cached. This generator's `--build-apk` option uses a **system Gradle executable only** (or `--gradle-bin`), and refuses to use the supplied Gradle wrapper or download a Gradle distribution.

Optional build attempt:

```sh
python3 tools/gameport_winlator_fork.py \
  --winlator-source /path/to/winlator-app-main.zip \
  --game-package /path/to/MyGame_GamePortBuildPackage.zip \
  --output /path/to/MyGame_WinlatorProject.zip \
  --build-apk
```

If the toolchain is missing, it still writes and CRC-checks the source project ZIP, then returns exit code `2` and reports blockers.


## Build requirements (from supplied Winlator source)

- Android SDK Platform 35 / `android.jar`
- Android Build Tools 35.0.0
- JDK 17
- Android NDK `24.0.8215888`
- CMake `3.22.1`
- System Gradle 8.6+ compatible with upstream AGP 8.4.2; build mode requires dependencies already cached and uses `--offline`

The generated APK contains the Winlator runtime and game assets, so its file size will be large. The APK is ARM64-oriented, as is the supplied Winlator build.


## Stable app IDs and updates

Package ID is derived deterministically from normalized game title and EXE path, for example `com.gameport.games.hood_warfare_2.h1234abcd`. Rebuilding the same game keeps the package ID. To update-install, use a higher `--version-code` and sign with the same certificate/key as the previous build. This project does not embed a private signing key. Android will reject an update if the signing certificate differs.


## Winlator source and licenses

The generator uses the Winlator source archive supplied by the user. It does not use the standalone Winlator APK as a binary template. The output source fork retains the upstream LICENSE and repository notices. Winlator is licensed under LGPL 2.1; bundled runtime and third-party components may have separate notices and obligations, which must be retained. The user's game files are their own payload and remain subject to their game license.


## Test target

Hood Warfare 2 remains a benchmark only. A packaged Windows build cannot be reconstructed into an Android native port without legitimate source/project/build access. No EAC bypass is attempted.

## GitHub Actions build and stable app identity (1.0.1 CI)

The main GamePort app ID is fixed at `com.gameport.mobile` and must not change between updates. The CI workflow `.github/workflows/build-apk.yml` builds a debug APK on pushes to `main`/`master` and via **Actions → GamePort Android APK → Run workflow**. It uses Gradle 8.9, JDK 17, Android platform 35 and Build Tools 34.0.0, then checks the APK package ID and version name before uploading it.

Debug APKs use CI's debug signing key and are not guaranteed to update-install over APKs from other runners. To make signed release APKs update-install consistently, configure these GitHub Actions secrets with the same keystore/certificate used for prior releases: `GAMEPORT_KEYSTORE_BASE64`, `GAMEPORT_KEYSTORE_PASSWORD`, `GAMEPORT_KEY_ALIAS`, and `GAMEPORT_KEY_PASSWORD`. The manually triggered release job is skipped if no keystore secret is configured. Never commit the keystore or credentials. Version code is `1000 + GITHUB_RUN_NUMBER`, and version name is `1.0.1-ci`; package ID remains unchanged.
