# GamePort 1.0.1-ci

- Preserved the main Android application ID `com.gameport.mobile`; package identity does not change across app updates.
- Added GitHub Actions debug APK workflow using JDK 17, Gradle 8.9, Android Platform 35 and Build Tools 34.0.0.
- CI verifies APK package name/version before publishing the debug artifact.
- Added optional manually-triggered release APK build with persistent keystore secrets; missing or invalid signing credentials skip/fail safely.
- Increased CI versionName to `1.0.1-ci`; versionCode remains `1000 + GITHUB_RUN_NUMBER`.
- Added CI workflow YAML and package-identity tests.

No Android APK has been compiled locally because Gradle and Android SDK are unavailable here. CI workflow is added but has not been triggered against a remote GitHub repository in this session.
