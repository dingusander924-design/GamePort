# v0.9.1 — Winlator companion setup + game ZIP export

- Added Winlator Companion screen with official release links, v9.0 historical release link, install/setup checklist, source ZIP clarification, and launch-if-installed action.
- Added package visibility query for `com.winlator`.
- Added per-game ZIP export via Android SAF so GamePort's private imported files can be copied into a user-selected accessible location for Winlator. Export includes path-safe checks and progress updates.
- Removed the private PKCS12 keystore and its embedded password from the project archive; debug signing now uses the local build environment's key. This can break update compatibility with previously installed v0.9.0 builds.
- Android SDK/Gradle build remains unverified in this environment.
