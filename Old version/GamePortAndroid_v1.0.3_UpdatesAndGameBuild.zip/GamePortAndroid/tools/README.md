# GamePort Winlator Source Fork Builder

This tool creates a customized Winlator **source project**, not an APK by itself. The game-package ZIP is exported from GamePort and must contain:


- `gameport/game_manifest.json` with `schemaVersion: 1`, `title`, and `executable` relative to the payload root.
- `gameport/game_payload.zip` containing the game's files, including the selected `.exe`.

Example:

```sh
python3 gameport_winlator_fork.py \
  --winlator-source winlator-app-main.zip \
  --game-package MyGame_GamePortBuildPackage.zip \
  --output MyGame_WinlatorProject.zip
```

Build option (local toolchain only):

```sh
python3 gameport_winlator_fork.py \
  --winlator-source winlator-app-main.zip \
  --game-package MyGame_GamePortBuildPackage.zip \
  --output MyGame_WinlatorProject.zip \
  --build-apk
```

`--build-apk` checks for system Gradle 8.6+, JDK 17, SDK platform 35, Build Tools 35.0.0, NDK 24.0.8215888, and CMake 3.22.1. It uses system Gradle `--offline` only; it will not invoke the upstream wrapper or download toolchain binaries. Use `--gradle-bin /absolute/path/to/gradle` if Gradle is not on PATH.


The APK build will be ARM64, will include the Winlator runtime plus game payload, and will be large. Package ID is stable for a title/executable pair; updates require increasing `--version-code` and retaining the same signing certificate.
