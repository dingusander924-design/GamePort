#!/usr/bin/env python3
import io
import struct
import zlib
import warnings
import json
import os
import sys
import subprocess
import tempfile
import unittest
import zipfile
from pathlib import Path

import gameport_winlator_fork as gp


def make_source_zip(path: Path):
    files = {
        "winlator-app-main/settings.gradle": "include ':app'\n",
        "winlator-app-main/app/build.gradle": """android { namespace 'com.winlator'\n defaultConfig { applicationId 'com.winlator'; versionCode 33; versionName \"11.2\" } }\n""",
        "winlator-app-main/app/src/main/res/values/strings.xml": "<resources><string name=\"app_name\">Winlator</string></resources>\n",
        "winlator-app-main/app/src/main/AndroidManifest.xml": "<manifest><provider android:authorities=\"com.winlator.FileProvider\"/></manifest>\n",
        "winlator-app-main/app/src/main/java/com/winlator/core/FileUtils.java": "package com.winlator.core; class FileUtils { String a=\"com.winlator.FileProvider\"; }\n",
        "winlator-app-main/app/src/main/java/com/winlator/MainActivity.java": """package com.winlator; public class MainActivity { void setup(){ if (!requestAppPermissions()) RootFSInstaller.installIfNeeded(this); } void onRequestPermissionsResult(){ if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {\n                RootFSInstaller.installIfNeeded(this);\n            } } }\n""",
        "winlator-app-main/app/src/main/java/com/winlator/xenvironment/RootFSInstaller.java": """package com.winlator.xenvironment; public class RootFSInstaller {
    public static void install(final MainActivity activity) {
            if (success) {
                rootFS.createRFSVersionFile(LATEST_VERSION);
                resetContainerRFSVersions(activity);
            }
            else AppUtils.showToast(activity, R.string.unable_to_install_system_files);

            dialog.closeOnUiThread();
    }
    public static void installIfNeeded(final MainActivity activity) {
        RootFS rootFS = RootFS.find(activity);
        if (!rootFS.isValid() || rootFS.getVersion() < LATEST_VERSION) install(activity);
    }
}\n""",
    }
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in files.items(): z.writestr(name, content)


def tiny_png(width, height, rgba=(20, 60, 100, 255)):
    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xffffffff)
    row = bytes([0]) + bytes(rgba) * width
    raw = row * height
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


def make_game_package(path: Path, exe="bin/TestGame.exe", extra=None, payload_exe=None):
    inner = io.BytesIO()
    with zipfile.ZipFile(inner, "w", zipfile.ZIP_DEFLATED) as payload:
        payload.writestr(payload_exe or exe, b"test-executable-data")
        payload.writestr("data/config.txt", b"test")
        if extra:
            for name, value in extra.items(): payload.writestr(name, value)
    manifest = {"schemaVersion": 1, "title": "Test Game", "executable": exe}
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as package:
        package.writestr("gameport/game_manifest.json", json.dumps(manifest))
        package.writestr("gameport/game_payload.zip", inner.getvalue())
        for bucket, size in gp.ICON_BUCKETS.items():
            package.writestr(f"gameport/icons/ic_launcher-{bucket}.png", tiny_png(size,size))
        package.writestr("gameport/icons/ic_launcher-foreground.png", tiny_png(108,108))



class BuilderTests(unittest.TestCase):
    def test_package_id_deterministic(self):
        a = gp.package_id_for("Hood Warfare 2", "bin/Hood.exe")
        b = gp.package_id_for("Hood Warfare 2", "bin/Hood.exe")
        self.assertEqual(a, b)
        self.assertRegex(a, r"^com\.gameport\.games\.[a-z0-9_]+\.h[0-9a-f]{12}$")

    def test_safe_path_rejects_traversal(self):
        for path in ("../escape.exe", "C:/escape.exe", "/root.exe", "foo/../../bar.exe"):
            with self.subTest(path=path), self.assertRaises(ValueError): gp._safe_member(path)

    def test_package_reader_checks_executable_and_payload_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            t = Path(tmp); source = t / "src.zip"; package = t / "game.zip"; payload = t / "payload.zip"
            make_source_zip(source); make_game_package(package)
            manifest, payload_path, icons = gp.read_game_package(package, payload)
            self.assertEqual(manifest["executable"], "bin/TestGame.exe")
            self.assertEqual(len(manifest["payloadSha256"]), 64)
            self.assertEqual(payload_path, payload)
            self.assertEqual(set(icons.keys()), set(gp.ICON_BUCKETS) | {"foreground"})

    def test_package_rejects_missing_executable(self):
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); p=t/"pkg.zip"; payload=t/"payload.zip"
            make_game_package(p, exe="missing.exe", payload_exe="bin/TestGame.exe")
            with self.assertRaisesRegex(ValueError, "Executable not found"):
                gp.read_game_package(p, payload)

    def test_generator_patches_project_and_adds_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); src=t/"winlator.zip"; pkg=t/"game-package.zip"; out=t/"project"
            make_source_zip(src); make_game_package(pkg)
            result=gp.make_project(src,pkg,out,None,101)
            project=Path(result["projectDir"])
            self.assertEqual(result["versionCode"],101)
            self.assertEqual(result["packageId"],gp.package_id_for("Test Game","bin/TestGame.exe"))
            gradle=(project/gp.APP_GRADLE).read_text()
            self.assertIn("applicationId '"+result["packageId"]+"'",gradle)
            self.assertIn("versionCode 101",gradle)
            self.assertIn('versionName "1.0.0"',gradle)
            strings=(project/gp.STRINGS_XML).read_text()
            self.assertIn("Test Game",strings)
            self.assertTrue((project/gp.GAMEPORT_ASSETS/"game_manifest.json").is_file())
            self.assertTrue((project/gp.GAMEPORT_ASSETS/"game_payload.zip").is_file())
            self.assertTrue((project/"app/src/main/res/drawable/ic_launcher_foreground.png").is_file())
            self.assertFalse((project/"app/src/main/res/drawable/ic_launcher_foreground.xml").exists())
            self.assertTrue((project/"app/src/main/res/mipmap-xxhdpi/ic_launcher.png").is_file())
            provider=(project/"app/src/main/AndroidManifest.xml").read_text()
            self.assertIn(result["packageId"]+".FileProvider",provider)
            file_utils=(project/gp.FILE_UTILS).read_text()
            self.assertIn(result["packageId"]+".FileProvider",file_utils)
            bootstrap=(project/"app/src/main/java/com/winlator/GamePortBootstrap.java").read_text()
            self.assertIn("XServerDisplayActivity",bootstrap)
            self.assertIn("payloadSha256",bootstrap)
            main=(project/gp.MAIN_ACTIVITY).read_text()
            self.assertEqual(main.count("GamePortBootstrap.start(this)"),2)
            self.assertLess(main.index("GamePortBootstrap.isGamePortBuild(this)"), main.index("requestAppPermissions()"))
            rootfs=(project/gp.ROOTFS_INSTALLER).read_text()
            self.assertIn("Runnable onComplete",rootfs)
            self.assertIn("onComplete.run()",rootfs)
            build_info=(project/"GAMEPORT_BUILD_INFO.txt").read_text()
            self.assertIn("Winlator source ZIP SHA-256",build_info)
            self.assertIn("source revision",build_info.lower())

    def test_zip_entry_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); pkg=t/"pkg.zip"; payload=t/"payload.zip"
            inner=io.BytesIO()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                with zipfile.ZipFile(inner,"w") as z:
                    z.writestr("TestGame.exe",b"a")
                    z.writestr("TestGame.exe",b"b")
            with zipfile.ZipFile(pkg,"w") as z:
                z.writestr("gameport/game_manifest.json",json.dumps({"schemaVersion":1,"title":"Test","executable":"TestGame.exe"}))
                z.writestr("gameport/game_payload.zip",inner.getvalue())
            with self.assertRaisesRegex(ValueError,"Duplicate payload path"):
                gp.read_game_package(pkg,payload)

    def test_generated_java_bootstrap_compiles_with_api_stubs(self):
        javac = shutil_which("javac")
        if not javac: self.skipTest("javac unavailable")
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); files={
              "android/content/Context.java":"package android.content; public class Context { public android.content.res.AssetManager getAssets(){return new android.content.res.AssetManager();} }",
              "android/content/Intent.java":"package android.content; public class Intent { public Intent(Context c, Class<?> cls){} public Intent putExtra(String k,int v){return this;} public Intent putExtra(String k,String v){return this;} }",
              "android/content/res/AssetManager.java":"package android.content.res; public class AssetManager { public java.io.InputStream open(String s) throws java.io.IOException {return new java.io.ByteArrayInputStream(new byte[0]);} }",
              "android/app/Activity.java":"package android.app; public class Activity extends android.content.Context { public void runOnUiThread(Runnable r){} public void startActivity(android.content.Intent i){} public void finish(){} }",
              "android/widget/Toast.java":"package android.widget; public class Toast { public static final int LENGTH_LONG=1; public static Toast makeText(android.content.Context c,String s,int d){return new Toast();} public void show(){} }",
              "org/json/JSONObject.java":"package org.json; public class JSONObject { public JSONObject(String s){} public JSONObject(){} public String getString(String s) throws Exception{return \"\";} public String optString(String s,String d){return d;} public JSONObject put(String s,Object o) throws Exception{return this;} }",
              "com/winlator/MainActivity.java":"package com.winlator; public class MainActivity extends android.app.Activity{}",
              "com/winlator/XServerDisplayActivity.java":"package com.winlator; public class XServerDisplayActivity extends android.app.Activity{}",
              "com/winlator/core/StringUtils.java":"package com.winlator.core; public class StringUtils { public static String escapeDOSPath(String s){return s;} }",
              "com/winlator/xenvironment/RootFS.java":"package com.winlator.xenvironment; public class RootFS { public static RootFS find(android.content.Context c){return new RootFS();} public boolean isValid(){return true;} public java.io.File getRootDir(){return new java.io.File(\".\");} }",
              "com/winlator/container/Container.java":"package com.winlator.container; public class Container { public int id; public java.io.File getRootDir(){return new java.io.File(\".\");} public java.io.File getUserDir(){return new java.io.File(\".\");} public String getExtra(String k){return \"\";} }",
              "com/winlator/container/ContainerManager.java":"package com.winlator.container; public class ContainerManager { public interface Cb { void call(Container c);} public ContainerManager(android.content.Context c){} public java.util.List<Container> getContainers(){return new java.util.ArrayList<>();} public void createContainerAsync(org.json.JSONObject j,Cb cb){cb.call(new Container());} public void activateContainer(Container c){} }",
            }
            stubroot=t/"stubs"
            for rel, content in files.items():
                path=stubroot/rel; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(content)
            source=t/"GamePortBootstrap.java"; source.write_text(gp.BOOTSTRAP_JAVA)
            result=subprocess.run([javac,"-source","8","-target","8","-d",str(t/"classes"),*[str(p) for p in stubroot.rglob("*.java")],str(source)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)

    def test_cli_creates_crc_valid_project_archive(self):
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); src=t/"winlator-source.zip"; pkg=t/"game-package.zip"; out=t/"generated-project.zip"
            make_source_zip(src); make_game_package(pkg)
            script=Path(gp.__file__)
            proc=subprocess.run([sys.executable,str(script),"--winlator-source",str(src),"--game-package",str(pkg),"--output",str(out)],capture_output=True,text=True)
            self.assertEqual(proc.returncode,0,proc.stderr)
            self.assertTrue(out.is_file())
            with zipfile.ZipFile(out) as z:
                self.assertIsNone(z.testzip())
                self.assertIn("WinlatorGameProject/app/src/main/java/com/winlator/GamePortBootstrap.java",z.namelist())
                self.assertIn("WinlatorGameProject/app/src/main/assets/gameport/game_payload.zip",z.namelist())

    def test_build_preflight_reports_missing_android_toolchain(self):
        with tempfile.TemporaryDirectory() as tmp:
            project=Path(tmp)
            issues=gp._build_preflight(project)
            self.assertTrue(any("Gradle" in issue for issue in issues))
            self.assertTrue(any("Android SDK" in issue or "ANDROID_SDK" in issue for issue in issues))
            self.assertTrue(any("JDK 17" in issue for issue in issues))

    def test_gameport_ui_no_longer_claims_clone_apk_build(self):
        root=Path(gp.__file__).parent.parent
        port=(root/"app/src/main/java/com/gameport/mobile/PortActivity.kt").read_text()
        self.assertIn("Export build package",port)
        self.assertIn("Test controls",port)
        self.assertNotIn("ApkForge.forge",port)
        self.assertFalse((root/"app/src/main/java/com/gameport/mobile/ApkForge.kt").exists())

    def test_zip_slip_and_symlink_payloads_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); pkg=t/"bad.zip"; payload=t/"payload.zip"
            inner=io.BytesIO()
            with zipfile.ZipFile(inner,"w") as z:
                z.writestr("TestGame.exe",b"exe")
                z.writestr("../outside.txt",b"escape")
            with zipfile.ZipFile(pkg,"w") as z:
                z.writestr("gameport/game_manifest.json",json.dumps({"schemaVersion":1,"title":"Test","executable":"TestGame.exe"}))
                z.writestr("gameport/game_payload.zip",inner.getvalue())
            with self.assertRaisesRegex(ValueError,"Unsafe archive path"):
                gp.read_game_package(pkg,payload)
            inner=io.BytesIO()
            with zipfile.ZipFile(inner,"w") as z:
                z.writestr("TestGame.exe",b"exe")
                link=zipfile.ZipInfo("evil-link")
                link.external_attr=(0o120777 << 16)
                z.writestr(link,"../target")
            with zipfile.ZipFile(pkg,"w") as z:
                z.writestr("gameport/game_manifest.json",json.dumps({"schemaVersion":1,"title":"Test","executable":"TestGame.exe"}))
                z.writestr("gameport/game_payload.zip",inner.getvalue())
            with self.assertRaisesRegex(ValueError,"Symlink"):
                gp.read_game_package(pkg,payload)

    def test_build_apk_blocked_still_emits_project_zip(self):
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); src=t/"source.zip"; pkg=t/"game.zip"; out=t/"project.zip"
            make_source_zip(src); make_game_package(pkg)
            proc=subprocess.run([sys.executable,str(Path(gp.__file__)),"--winlator-source",str(src),"--game-package",str(pkg),"--output",str(out),"--build-apk"],capture_output=True,text=True)
            self.assertEqual(proc.returncode,2)
            self.assertTrue(out.is_file())
            with zipfile.ZipFile(out) as z: self.assertIsNone(z.testzip())
    def test_gradle_failure_keeps_source_zip_and_reports_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp); src=t/"source.zip"; pkg=t/"game.zip"; out=t/"project.zip"
            make_source_zip(src); make_game_package(pkg)
            gradle=t/"gradle"; gradle.write_text("#!/bin/sh\nif [ \"$1\" = \"--version\" ]; then echo 'Gradle 8.9'; exit 0; fi\nexit 1\n"); gradle.chmod(0o755)
            java_home=t/"jdk"; java_bin=java_home/"bin/java"; java_bin.parent.mkdir(parents=True); java_bin.write_text("#!/bin/sh\necho 'openjdk version \"17.0.0\"' >&2\n"); java_bin.chmod(0o755)
            sdk=t/"sdk"; (sdk/"platforms/android-35").mkdir(parents=True); (sdk/"platforms/android-35/android.jar").write_bytes(b"stub")
            (sdk/"build-tools/35.0.0").mkdir(parents=True); (sdk/"ndk/24.0.8215888").mkdir(parents=True)
            cmake=sdk/"cmake/3.22.1/bin/cmake"; cmake.parent.mkdir(parents=True); cmake.write_text("#!/bin/sh\nexit 0\n"); cmake.chmod(0o755)
            env=os.environ.copy(); env["ANDROID_SDK_ROOT"]=str(sdk); env["JAVA_HOME"]=str(java_home)
            proc=subprocess.run([sys.executable,str(Path(gp.__file__)),"--winlator-source",str(src),"--game-package",str(pkg),"--output",str(out),"--build-apk","--gradle-bin",str(gradle)],capture_output=True,text=True,env=env)
            self.assertEqual(proc.returncode,2)
            self.assertIn("APK build failed",proc.stderr)
            self.assertTrue(out.is_file())
            with zipfile.ZipFile(out) as z: self.assertIsNone(z.testzip())


    def test_portactivity_kotlin_parser_has_no_syntax_markers(self):
        kotlinc=shutil_which("kotlinc")
        if not kotlinc: self.skipTest("Kotlin compiler not installed")
        root=Path(gp.__file__).parent.parent
        source=root/"app/src/main/java/com/gameport/mobile/PortActivity.kt"
        with tempfile.TemporaryDirectory() as tmp:
            proc=subprocess.run([kotlinc,str(source),"-d",str(Path(tmp)/"out")],capture_output=True,text=True)
            diagnostics=proc.stdout+proc.stderr
            self.assertNotRegex(diagnostics,r"\bexpecting\b|unexpected tokens|syntax error|conflicting declarations")
            self.assertIn("Export build package",source.read_text())

    def test_gameport_build_package_export_wires_metadata_payload_and_icons(self):
        root=Path(gp.__file__).parent.parent
        port=(root/"app/src/main/java/com/gameport/mobile/PortActivity.kt").read_text()
        self.assertIn("gameport/game_manifest.json",port)
        self.assertIn("gameport/game_payload.zip",port)
        self.assertIn("gameport/icons/ic_launcher-foreground.png",port)
        self.assertIn("ZipFile(packageFile)",port)
        self.assertIn("CRC32",port)
        self.assertIn("CRC32",port)
        self.assertIn("1_900_000_000L",port)
        self.assertIn("200000",port)



def shutil_which(name):
    import shutil
    return shutil.which(name)


if __name__ == "__main__":
    unittest.main(verbosity=2)
