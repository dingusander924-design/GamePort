#!/usr/bin/env python3
"""Static sanity checks for the GamePort Winlator companion integration."""
from pathlib import Path
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ACTIVITY = ROOT / "app/src/main/java/com/gameport/mobile/WinlatorActivity.kt"
PORT = ROOT / "app/src/main/java/com/gameport/mobile/PortActivity.kt"
MAIN = ROOT / "app/src/main/java/com/gameport/mobile/MainActivity.kt"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    activity = ACTIVITY.read_text()
    port = PORT.read_text()
    main = MAIN.read_text()
    manifest = MANIFEST.read_text()


    check("https://github.com/brunodev85/winlator/releases" in activity, "official release link missing")
    check("v9.0.0" in activity, "v9.0 release link missing")
    check("archive/refs/heads/main.zip" in activity, "optional source ZIP link missing")
    check("com.winlator" in activity and "getLaunchIntentForPackage" in activity, "external launch hook missing")
    check("WinlatorActivity" in main, "main screen integration button missing")
    check('android:name="com.winlator"' in manifest, "package visibility query missing")
    check("Export game ZIP" in port, "game ZIP export UI missing")
    check("ACTION_CREATE_DOCUMENT" in port and "203" in port, "SAF export chooser missing")
    check("canonicalPath" in port and "File escaped game directory" in port, "canonical path guard missing")
    check("ZipOutputStream" in port and "ZipEntry(rel)" in port, "ZIP stream implementation missing")
    check("pendingZipGame = null" in port, "cancel/stale export state reset missing")
    check(not (ROOT / "app/gameport-signing.p12").exists(), "private signing key should not be packaged")

    # Exercise path-preserving ZIP behavior on a temporary fixture and verify CRC/readback.
    with tempfile.TemporaryDirectory() as td:
        game = Path(td) / "game"
        (game / "bin" / "data").mkdir(parents=True)
        (game / "game.exe").write_bytes(b"sample-exe")
        (game / "bin" / "data" / "file.dat").write_bytes(b"nested sample")
        out = Path(td) / "export.zip"
        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for f in game.rglob("*"):
                if not f.is_file():
                    continue
                resolved = str(f.resolve())
                check(resolved.startswith(str(game.resolve()) + "/"), "fixture file outside root")
                z.write(f, f.relative_to(game).as_posix())
        with zipfile.ZipFile(out) as z:
            check(z.testzip() is None, "fixture ZIP CRC failed")
            check("game.exe" in z.namelist(), "top-level file path lost")
            check("bin/data/file.dat" in z.namelist(), "nested path lost")
            check(z.read("bin/data/file.dat") == b"nested sample", "ZIP readback mismatch")
    print("Winlator companion checks: PASS (11 source assertions + ZIP fixture round-trip)")


if __name__ == "__main__":
    main()
