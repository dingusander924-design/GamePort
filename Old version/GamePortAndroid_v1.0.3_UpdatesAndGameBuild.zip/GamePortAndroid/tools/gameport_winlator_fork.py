#!/usr/bin/env python3
"""Generate a per-game Android project fork of Winlator from user-provided sources.

This tool does not convert Windows executables. It creates a customized Winlator
source project with the game payload bundled as an asset. Build the resulting
Android project with the matching Android SDK/NDK and Gradle toolchain.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from xml.sax.saxutils import escape as xml_escape



APP_DIR = "app"
MAIN_ACTIVITY = "app/src/main/java/com/winlator/MainActivity.java"
ROOTFS_INSTALLER = "app/src/main/java/com/winlator/xenvironment/RootFSInstaller.java"
FILE_UTILS = "app/src/main/java/com/winlator/core/FileUtils.java"
STRINGS_XML = "app/src/main/res/values/strings.xml"
APP_GRADLE = "app/build.gradle"
GAMEPORT_ASSETS = "app/src/main/assets/gameport"
MAX_SOURCE_BYTES = 1_000_000_000
MAX_GAME_BYTES = 10_000_000_000
MAX_PAYLOAD_ARCHIVE_BYTES = 1_900_000_000
MAX_FILES = 200_000
ICON_BUCKETS = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}



def _safe_member(name: str) -> str:
    n = name.replace("\\", "/")
    p = PurePosixPath(n)
    if not n or n.startswith("/") or any(part in ("..", "", ".") for part in p.parts) or ":" in n:
        raise ValueError(f"Unsafe archive path: {name!r}")
    return str(p)



def package_id_for(title: str, executable: str) -> str:
    base = re.sub(r"[^a-z0-9_]+", "_", title.lower()).strip("_") or "game"
    if not base[0].isalpha(): base = "g_" + base
    base = base[:24].rstrip("_") or "game"
    digest = hashlib.sha256((title.strip().casefold() + "\0" + executable.replace("\\", "/").casefold()).encode()).hexdigest()[:12]
    package = f"com.gameport.games.{base}.h{digest}"
    if not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){2,}", package):
        raise ValueError("Generated package ID is invalid")
    return package



def validate_package_id(value: str) -> str:
    segments = value.split(".")
    if (not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){2,}", value) or
            any(len(part) > 63 for part in segments) or len(value) > 255):
        raise ValueError("Package ID must be lowercase reverse-domain syntax (segments max 63 chars), e.g. com.gameport.games.mygame")
    return value



def read_game_package(package_zip: Path, payload_destination: Path) -> tuple[dict, Path, dict[str, bytes]]:
    with zipfile.ZipFile(package_zip) as outer:
        names = outer.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Game package contains duplicate archive entries")
        for outer_name in names:
            _safe_member(outer_name.rstrip("/"))
        manifest_name = "gameport/game_manifest.json"
        payload_name = "gameport/game_payload.zip"
        if manifest_name not in names or payload_name not in names:
            raise ValueError("Game package must contain gameport/game_manifest.json and gameport/game_payload.zip")
        manifest = json.loads(outer.read(manifest_name).decode("utf-8"))
        if manifest.get("schemaVersion") != 1:
            raise ValueError("Unsupported game package schema (expected version 1)")
        title = "".join(ch for ch in str(manifest.get("title", "")).strip() if ch.isprintable())
        exe = _safe_member(str(manifest.get("executable", "")))
        if not title or len(title) > 80:
            raise ValueError("Game title must be 1–80 characters")
        if not exe.lower().endswith(".exe"):
            raise ValueError("Selected executable must end in .exe")
        info = outer.getinfo(payload_name)
        icon_data = {}
        for bucket, expected_size in ICON_BUCKETS.items():
            icon_path = f"gameport/icons/ic_launcher-{bucket}.png"
            if icon_path in names:
                data = outer.read(icon_path)
                if len(data) > 512 * 1024 or not data.startswith(b"\x89PNG\r\n\x1a\n") or len(data) < 24:
                    raise ValueError(f"Invalid or oversized icon PNG: {icon_path}")
                width = int.from_bytes(data[16:20], "big")
                height = int.from_bytes(data[20:24], "big")
                if (width, height) != (expected_size, expected_size):
                    raise ValueError(f"Icon size mismatch for {bucket}: expected {expected_size}x{expected_size}")
                icon_data[bucket] = data
        foreground_path = "gameport/icons/ic_launcher-foreground.png"
        if foreground_path in names:
            data = outer.read(foreground_path)
            if len(data) > 512 * 1024 or not data.startswith(b"\x89PNG\r\n\x1a\n") or len(data) < 24:
                raise ValueError("Invalid or oversized adaptive foreground PNG")
            if (int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")) != (108, 108):
                raise ValueError("Adaptive foreground icon must be 108x108")
            icon_data["foreground"] = data
        if info.file_size > MAX_PAYLOAD_ARCHIVE_BYTES:
            raise ValueError("Compressed game payload exceeds APK asset size limit (1.9 GB)")
        digest = hashlib.sha256()
        with outer.open(payload_name) as source, payload_destination.open("wb") as target:
            while chunk := source.read(1024 * 1024):
                target.write(chunk)
                digest.update(chunk)
    with zipfile.ZipFile(payload_destination) as z:
        seen = set()
        total = 0
        found_exe = False
        for info in z.infolist():
            if info.is_dir():
                continue
            name = _safe_member(info.filename)
            normalized = name.casefold()
            if normalized in seen:
                raise ValueError(f"Duplicate payload path (case-insensitive): {name}")
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError(f"Symlink payload entry is not allowed: {name}")
            seen.add(normalized)
            total += info.file_size
            if total > MAX_GAME_BYTES:
                raise ValueError("Game payload exceeds 10 GB unpacked limit")
            if len(seen) > MAX_FILES:
                raise ValueError("Game payload exceeds 200,000 files")
            if name.casefold() == exe.casefold():
                found_exe = True
    if not found_exe:
        raise ValueError(f"Executable not found in payload: {exe}")
    stable_id = hashlib.sha256((title.strip().casefold() + "\0" + exe.casefold()).encode()).hexdigest()[:16]
    manifest = {"schemaVersion": 1, "title": title, "executable": exe, "gameId": stable_id, "payloadSha256": digest.hexdigest()}
    return manifest, payload_destination, icon_data


def extract_source(source_zip: Path, destination: Path) -> Path:
    with zipfile.ZipFile(source_zip) as z:
        entries = z.infolist()
        total = sum(i.file_size for i in entries)
        if total > MAX_SOURCE_BYTES:
            raise ValueError("Winlator source archive exceeds 1 GB unpacked limit")
        roots = set()
        for info in entries:
            safe = _safe_member(info.filename.rstrip("/"))
            roots.add(safe.split("/", 1)[0])
        if len(roots) != 1:
            raise ValueError("Winlator source ZIP must have exactly one top-level directory")
        for info in entries:
            if info.is_dir():
                continue
            safe = _safe_member(info.filename)
            target = destination.joinpath(*PurePosixPath(safe).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as src, target.open("wb") as out:
                shutil.copyfileobj(src, out, 1024 * 1024)
    root = destination / next(iter(roots))
    if not (root / "settings.gradle").exists() or not (root / APP_GRADLE).exists():
        raise ValueError("Archive does not appear to be a Winlator Gradle source project")
    return root



def _replace_once(path: Path, old: str, new: str, description: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise ValueError(f"Expected exactly one {description} patch anchor in {path}, found {count}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def patch_project(root: Path, manifest: dict, payload_path: Path, icons: dict[str, bytes], package_id: str, version_code: int, source_revision: str, source_sha256: str) -> None:
    # Identity changes while Winlator's internal namespace stays com.winlator.
    gradle = root / APP_GRADLE
    _replace_once(gradle, "applicationId 'com.winlator'", f"applicationId '{package_id}'", "applicationId")
    _replace_once(gradle, "versionCode 33", f"versionCode {version_code}", "versionCode")
    _replace_once(gradle, 'versionName "11.2"', 'versionName "1.0.0"', "versionName")
    strings = root / STRINGS_XML
    _replace_once(strings, '<string name="app_name">Winlator</string>',
                  f'<string name="app_name">{xml_escape(manifest["title"])}</string>', "app label")
    manifest_file = root / "app/src/main/AndroidManifest.xml"
    _replace_once(manifest_file, 'android:authorities="com.winlator.FileProvider"',
                  f'android:authorities="{package_id}.FileProvider"', "FileProvider authority")
    file_utils = root / FILE_UTILS
    _replace_once(file_utils, '"com.winlator.FileProvider"', f'"{package_id}.FileProvider"', "FileProvider source authority")

    assets = root / GAMEPORT_ASSETS
    assets.mkdir(parents=True, exist_ok=True)
    (assets / "game_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    shutil.copyfile(payload_path, assets / "game_payload.zip")
    if icons:
        icon_map = {
            "mdpi": "mipmap-mdpi", "hdpi": "mipmap-hdpi", "xhdpi": "mipmap-xhdpi",
            "xxhdpi": "mipmap-xxhdpi", "xxxhdpi": "mipmap-xxxhdpi",
        }
        for bucket, resource_folder in icon_map.items():
            if bucket in icons:
                resource_dir = root / "app/src/main/res" / resource_folder
                resource_dir.mkdir(parents=True, exist_ok=True)
                for icon_name in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
                    (resource_dir / icon_name).write_bytes(icons[bucket])
        if "foreground" in icons:
            drawable = root / "app/src/main/res/drawable"
            drawable.mkdir(parents=True, exist_ok=True)
            (drawable / "ic_launcher_foreground.xml").unlink(missing_ok=True)
            (drawable / "ic_launcher_foreground.png").write_bytes(icons["foreground"])
    (root / "GAMEPORT_BUILD_INFO.txt").write_text(
        "GamePort 1.0.0 generated Winlator fork\n"
        f"Package ID: {package_id}\n"
        f"Game: {manifest['title']}\n"
        f"Executable: {manifest['executable']}\n"
        f"Winlator source revision: {source_revision}\n"
        f"Winlator source ZIP SHA-256: {source_sha256}\n\n"
        "This is a modified Winlator source project. Preserve upstream and third-party notices.\n"
        "The included game payload is user-supplied; its license remains the user's responsibility.\n"
        "This project is not compiled or device-tested by the generator.\n", encoding="utf-8")

    # Add first-run bootstrap and safe extraction to the source project.
    bootstrap = root / "app/src/main/java/com/winlator/GamePortBootstrap.java"
    bootstrap.write_text(BOOTSTRAP_JAVA, encoding="utf-8")
    main = root / MAIN_ACTIVITY
    main_anchor = "if (!requestAppPermissions()) RootFSInstaller.installIfNeeded(this);"
    main_repl = (
        "if (GamePortBootstrap.isGamePortBuild(this)) RootFSInstaller.installIfNeeded(this, () -> GamePortBootstrap.start(this));\n"
        "            else if (!requestAppPermissions()) RootFSInstaller.installIfNeeded(this);"
    )
    _replace_once(main, main_anchor, main_repl, "MainActivity startup install hook")
    permission_anchor = (
        "if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {\n"
        "                RootFSInstaller.installIfNeeded(this);\n"
        "            }"
    )
    permission_repl = (
        "if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {\n"
        "                if (GamePortBootstrap.isGamePortBuild(this)) RootFSInstaller.installIfNeeded(this, () -> GamePortBootstrap.start(this));\n"
        "                else RootFSInstaller.installIfNeeded(this);\n"
        "            }"
    )
    _replace_once(main, permission_anchor, permission_repl, "permission-result install hook")

    rootfs = root / ROOTFS_INSTALLER
    install_anchor = "    public static void install(final MainActivity activity) {"
    install_repl = "    public static void install(final MainActivity activity) { install(activity, null); }\n\n    public static void install(final MainActivity activity, final Runnable onComplete) {"
    _replace_once(rootfs, install_anchor, install_repl, "RootFS install callback overload")
    close_anchor = (
        "            if (success) {\n"
        "                rootFS.createRFSVersionFile(LATEST_VERSION);\n"
        "                resetContainerRFSVersions(activity);\n"
        "            }\n"
        "            else AppUtils.showToast(activity, R.string.unable_to_install_system_files);\n\n"
        "            dialog.closeOnUiThread();"
    )
    close_repl = (
        "            if (success) {\n"
        "                rootFS.createRFSVersionFile(LATEST_VERSION);\n"
        "                resetContainerRFSVersions(activity);\n"
        "                activity.runOnUiThread(() -> { dialog.close(); if (onComplete != null) onComplete.run(); });\n"
        "            }\n"
        "            else {\n"
        "                AppUtils.showToast(activity, R.string.unable_to_install_system_files);\n"
        "                dialog.closeOnUiThread();\n"
        "            }"
    )
    _replace_once(rootfs, close_anchor, close_repl, "RootFS install callback completion")
    need_anchor = "    public static void installIfNeeded(final MainActivity activity) {\n        RootFS rootFS = RootFS.find(activity);\n        if (!rootFS.isValid() || rootFS.getVersion() < LATEST_VERSION) install(activity);\n    }"
    need_repl = (
        "    public static void installIfNeeded(final MainActivity activity) { installIfNeeded(activity, null); }\n\n"
        "    public static void installIfNeeded(final MainActivity activity, final Runnable onComplete) {\n"
        "        RootFS rootFS = RootFS.find(activity);\n"
        "        if (!rootFS.isValid() || rootFS.getVersion() < LATEST_VERSION) install(activity, onComplete);\n"
        "        else if (onComplete != null) onComplete.run();\n"
        "    }"
    )
    _replace_once(rootfs, need_anchor, need_repl, "RootFS installIfNeeded callback")


def _build_preflight(project: Path, gradle_override: str | None = None) -> list[str]:
    issues = []
    gradle = gradle_override or shutil.which("gradle")
    if not gradle:
        issues.append("System Gradle executable missing; build runner will not invoke the unverified source wrapper")
    else:
        try:
            proc = subprocess.run([gradle, "--version"], capture_output=True, text=True, timeout=15)
            text = proc.stdout + proc.stderr
            match = re.search(r"Gradle\s+(\d+)\.(\d+)", text)
            if proc.returncode != 0 or not match or (int(match.group(1)), int(match.group(2))) < (8, 6):
                issues.append("System Gradle 8.6+ required by upstream AGP 8.4.2")
        except Exception as e:
            issues.append(f"Gradle version check failed: {e}")
    sdk = os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
    if not sdk:
        issues.append("ANDROID_SDK_ROOT/ANDROID_HOME is unset")
    else:
        sdkp = Path(sdk)
        if not (sdkp / "platforms/android-35/android.jar").exists():
            issues.append("Android SDK platform 35/android.jar missing")
        if not (sdkp / "build-tools/35.0.0").exists():
            issues.append("Android Build Tools 35.0.0 missing")
        if not (sdkp / "ndk/24.0.8215888").exists():
            issues.append("Android NDK 24.0.8215888 missing")
        if not (sdkp / "cmake/3.22.1/bin/cmake").exists():
            issues.append("CMake 3.22.1 missing from Android SDK")
    java_home = os.environ.get("JAVA_HOME")
    java_bin = Path(java_home) / "bin/java" if java_home else Path(shutil.which("java") or "")
    if not java_bin.exists():
        issues.append("Java executable missing")
    else:
        try:
            proc = subprocess.run([str(java_bin), "-version"], capture_output=True, text=True, timeout=10)
            version_text = proc.stderr + proc.stdout
            if not re.search(r'"17(?:\.|$)', version_text):
                issues.append("Winlator build requires JDK 17; current Java does not report 17")
        except Exception as e:
            issues.append(f"Java version check failed: {e}")
    return issues


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024): digest.update(chunk)
    return digest.hexdigest()


def make_project(source_zip: Path, game_package: Path, project_dir: Path, package_id: str | None, version_code: int) -> dict:
    project_dir.mkdir(parents=True, exist_ok=True)
    payload_tmp = project_dir.parent / "gameport-payload-temp.zip"
    manifest, payload_path, icons = read_game_package(game_package, payload_tmp)
    with zipfile.ZipFile(source_zip) as source_archive:
        revision = source_archive.comment.decode("ascii", "ignore").strip()
    if not re.fullmatch(r"[0-9a-fA-F]{40}", revision): revision = "unknown"
    source_sha256 = file_sha256(source_zip)
    manifest["winlatorSourceRevision"] = revision
    manifest["winlatorSourceSha256"] = source_sha256
    pkg = validate_package_id(package_id or package_id_for(manifest["title"], manifest["executable"]))
    source_root = extract_source(source_zip, project_dir)
    # Flatten the source archive's outer folder so the generated project opens directly.
    if source_root != project_dir:
        target_root = project_dir / "WinlatorGameProject"
        if target_root.exists():
            raise FileExistsError(f"Project destination already exists: {target_root}")
        source_root.rename(target_root)
        source_root = target_root
    patch_project(source_root, manifest, payload_path, icons, pkg, version_code, revision, source_sha256)
    payload_tmp.unlink(missing_ok=True)
    return {"projectDir": str(source_root), "packageId": pkg, "title": manifest["title"], "executable": manifest["executable"], "versionCode": version_code}



def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--winlator-source", required=True, type=Path, help="Official/source ZIP of Winlator")
    ap.add_argument("--game-package", required=True, type=Path, help="GamePort build-package ZIP")
    ap.add_argument("--output", required=True, type=Path, help="Output source project ZIP path")
    ap.add_argument("--package-id", help="Override stable Android applicationId")
    ap.add_argument("--version-code", type=int, default=100, help="APK version code (increment for updates)")
    ap.add_argument("--build-apk", action="store_true", help="Build APK only if the local toolchain is already installed; never uses Gradle wrapper/download")
    ap.add_argument("--gradle-bin", help="Path to a system Gradle executable (optional; avoids PATH lookup)")
    args = ap.parse_args()
    if args.version_code < 1:
        ap.error("--version-code must be positive")
    if not args.winlator_source.is_file() or not args.game_package.is_file():
        ap.error("Input source ZIP and game package must exist")
    if args.output.exists():
        ap.error(f"Output already exists (won't overwrite): {args.output}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    build_blocked = False
    with tempfile.TemporaryDirectory(prefix="gameport-fork-") as temp:
        project_dir = Path(temp) / "project"
        result = make_project(args.winlator_source, args.game_package, project_dir, args.package_id, args.version_code)
        project = Path(result["projectDir"])
        built_apk = None
        if args.build_apk:
            issues = _build_preflight(project, args.gradle_bin)
            if issues:
                build_blocked = True
                print("APK build blocked by missing toolchain (source project ZIP will still be produced):", file=sys.stderr)
                for issue in issues: print(" - " + issue, file=sys.stderr)
            else:
                gradle = args.gradle_bin or shutil.which("gradle")
                if not gradle:
                    build_blocked = True
                    print("System Gradle missing; refusing to use/download an unverified wrapper.", file=sys.stderr)
                else:
                    try:
                        subprocess.run([gradle, "--offline", "assembleDebug"], cwd=project, check=True)
                        built_apk = project / "app/build/outputs/apk/debug/app-debug.apk"
                        if not built_apk.is_file(): raise RuntimeError("Gradle returned success but APK was not found")
                    except (subprocess.CalledProcessError, RuntimeError) as e:
                        build_blocked = True
                        built_apk = None
                        print(f"APK build failed; source project ZIP will still be produced: {e}", file=sys.stderr)
        # Create project ZIP. Include generated APK only if build actually succeeded.
        with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED, compresslevel=4) as out:
            for f in project.rglob("*"):
                if f.is_file():
                    rel = f.relative_to(project).as_posix()
                    if built_apk and f == built_apk:
                        out.write(f, "WinlatorGameProject/OUTPUT_APK/GamePortGame.apk")
                    else:
                        out.write(f, f"WinlatorGameProject/{rel}")
    with zipfile.ZipFile(args.output) as check:
        bad = check.testzip()
        if bad:
            raise RuntimeError(f"Output ZIP CRC failed at {bad}")
    print(json.dumps(result, indent=2))
    print(f"Created and verified: {args.output} ({args.output.stat().st_size} bytes)")
    return 2 if build_blocked else 0



BOOTSTRAP_JAVA = r'''package com.winlator;

import android.content.Intent;
import android.content.Context;
import android.widget.Toast;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.core.StringUtils;
import com.winlator.xenvironment.RootFS;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** First-run install and direct-launch bootstrap for generated GamePort Winlator forks. */
public final class GamePortBootstrap {
    private static final String MANIFEST = "gameport/game_manifest.json";
    private static final String PAYLOAD = "gameport/game_payload.zip";
    private static final String GAME_DIR = ".wine/drive_c/GamePort";
    private static final long MAX_UNPACKED_BYTES = 10L * 1024L * 1024L * 1024L;
    private static final int MAX_ENTRIES = 200000;
    private GamePortBootstrap() {}


    public static boolean isGamePortBuild(Context context) {
        try (InputStream in = context.getAssets().open(MANIFEST)) { return in != null; }
        catch (Exception e) { return false; }
    }

    public static void start(MainActivity activity) {
        try {
            JSONObject cfg = new JSONObject(readAsset(activity, MANIFEST));
            String gameId = cfg.getString("gameId");
            String title = cfg.getString("title");
            String exe = cfg.getString("executable").replace('\\', '/');
            if (gameId.isEmpty() || title.isEmpty() || !isSafeRelative(exe) || !exe.toLowerCase().endsWith(".exe")) throw new IllegalStateException("Invalid embedded game manifest");
            RootFS rootFS = RootFS.find(activity);
            if (!rootFS.isValid()) throw new IllegalStateException("Winlator system files were not installed");
            ContainerManager manager = new ContainerManager(activity);
            for (Container existing : manager.getContainers()) {
                if (gameId.equals(existing.getExtra("gameportBuildId"))) {
                    installAndLaunch(activity, existing, title, exe, gameId);
                    return;
                }
            }
            JSONObject data = new JSONObject().put("name", title).put("extraData", new JSONObject().put("gameportBuildId", gameId));
            manager.createContainerAsync(data, container -> {
                if (container == null) { fail(activity, "Could not create game container"); return; }
                installAndLaunch(activity, container, title, exe, gameId);
            });
        } catch (Exception e) { fail(activity, "Game setup failed: " + e.getMessage()); }
    }

    private static void installAndLaunch(MainActivity activity, Container container, String title, String exe, String gameId) {
        new Thread(() -> {
            try {
                File gameRoot = new File(container.getRootDir(), GAME_DIR);
                File marker = new File(gameRoot, ".gameport-installed");
                File exeFile = new File(gameRoot, exe);
                if (!exeFile.getCanonicalPath().startsWith(gameRoot.getCanonicalPath() + File.separator)) throw new SecurityException("Executable path escaped game folder");
                if (!marker.isFile() || !readFile(marker).equals(cfgPayloadHash(activity)) || !exeFile.isFile()) {
                    File stage = new File(container.getRootDir(), ".gameport-stage");
                    if (stage.exists()) deleteTree(stage);
                    if (!stage.mkdirs()) throw new IllegalStateException("Could not create staging folder");
                    extractPayload(activity, stage);
                    mergeTree(stage, gameRoot);
                    deleteTree(stage);
                    if (!new File(gameRoot, exe).isFile()) throw new IllegalStateException("Game EXE is missing after unpacking");
                    writeFile(marker, cfgPayloadHash(activity));
                }
                File desktop = new File(container.getUserDir(), "Desktop");
                if (!desktop.exists() && !desktop.mkdirs()) throw new IllegalStateException("Could not create game shortcut folder");
                File shortcut = new File(desktop, "GamePortGame.desktop");
                String dosExe = "C:\\GamePort\\" + exe.replace('/', '\\');
                String desktopTitle = title.replace('\n', ' ').replace('\r', ' ').replace('=', ' ');
                String contents = "[Desktop Entry]\nName=" + desktopTitle + "\nExec=wine " + StringUtils.escapeDOSPath(dosExe) + "\n";
                if (!shortcut.exists() || !readFile(shortcut).equals(contents)) writeFile(shortcut, contents);
                activity.runOnUiThread(() -> {
                    try {
                        ContainerManager cm = new ContainerManager(activity);
                        cm.activateContainer(container);
                        Intent intent = new Intent(activity, XServerDisplayActivity.class);
                        intent.putExtra("container_id", container.id);
                        intent.putExtra("shortcut_path", shortcut.getAbsolutePath());
                        activity.startActivity(intent);
                        activity.finish();
                    } catch (Exception e) { fail(activity, "Could not launch game: " + e.getMessage()); }
                });
            } catch (Exception e) { activity.runOnUiThread(() -> fail(activity, "Game install failed: " + e.getMessage())); }
        }).start();
    }


    private static void extractPayload(Context context, File destination) throws Exception {
        String base = destination.getCanonicalPath() + File.separator;
        long total = 0; int entries = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(context.getAssets().open(PAYLOAD)))) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                if (++entries > MAX_ENTRIES) throw new IllegalStateException("Game archive contains too many entries");
                String name = entry.getName().replace('\\', '/');
                if (name.length() == 0) continue;
                if (name.startsWith("/") || name.contains(":") || name.equals("..") || name.startsWith("../") || name.contains("/../")) throw new SecurityException("Unsafe game archive path");
                File output = new File(destination, name);
                if (!output.getCanonicalPath().startsWith(base)) throw new SecurityException("Game archive escaped install directory");
                if (entry.isDirectory()) output.mkdirs();
                else {
                    output.getParentFile().mkdirs();
                    try (FileOutputStream out = new FileOutputStream(output)) {
                        byte[] buffer = new byte[65536]; int n;
                        while ((n = zin.read(buffer)) != -1) {
                            total += n;
                            if (total > MAX_UNPACKED_BYTES) throw new IllegalStateException("Game archive exceeds 10 GB unpacked limit");
                            out.write(buffer, 0, n);
                        }
                    }
                }
            }
        }
    }
    private static boolean isSafeRelative(String path) {
        if (path == null || path.length() == 0 || path.startsWith("/") || path.contains(":")) return false;
        for (String part : path.split("/")) if (part.length() == 0 || part.equals(".") || part.equals("..")) return false;
        return true;
    }
    private static String cfgPayloadHash(Context context) throws Exception {
        JSONObject cfg = new JSONObject(readAsset(context, MANIFEST));
        String hash = cfg.optString("payloadSha256", "");
        if (!hash.matches("[0-9a-f]{64}")) throw new IllegalStateException("Invalid payload checksum in game manifest");
        return hash;
    }
    private static void mergeTree(File source, File target) throws Exception {
        File[] files = source.listFiles();
        if (files == null) return;
        if (!target.exists() && !target.mkdirs()) throw new IllegalStateException("Could not create game directory");
        for (File file : files) {
            File out = new File(target, file.getName());
            if (file.isDirectory()) mergeTree(file, out);
            else { out.getParentFile().mkdirs(); try (java.io.FileInputStream in = new java.io.FileInputStream(file); FileOutputStream fos = new FileOutputStream(out)) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) != -1) fos.write(b, 0, n); } }
        }
    }
    private static String readAsset(Context context, String name) throws Exception {
        try (InputStream in = context.getAssets().open(name)) {
            byte[] bytes = new byte[65536]; java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(); int n;
            while ((n = in.read(bytes)) != -1) out.write(bytes, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
    private static String readFile(File file) throws Exception {
        java.io.FileInputStream in = new java.io.FileInputStream(file);
        try { java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(); byte[] b = new byte[4096]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n); return out.toString(StandardCharsets.UTF_8.name()); }
        finally { in.close(); }
    }
    private static void writeFile(File file, String value) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(value.getBytes(StandardCharsets.UTF_8)); }
    }
    private static void deleteTree(File file) {
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }
    private static void fail(MainActivity activity, String message) {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
    }
}
'''


if __name__ == "__main__":
    raise SystemExit(main())
