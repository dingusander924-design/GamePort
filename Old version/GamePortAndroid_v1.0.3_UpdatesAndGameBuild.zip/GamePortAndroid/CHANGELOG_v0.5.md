# v0.5 changelog
- Added scrollable main workbench UI.
- Added single-file import entry point alongside folder import.
- Added recursive inventory size and extension histogram.
- Improved project/source and anti-cheat indicator diagnostics.
- Added text assessment export and JSON inventory export.
- Added Touch Layout Designer: FPS/twin-stick/driving/minimal preset previews, control scale and opacity sliders, reset, JSON save.
- Added AndroidX DocumentFile dependency (missing from prior prototype Gradle setup).
- Updated application version to 0.5.0 / versionCode 5.
- Documentation clarifies prototype boundaries and unverified build status.
