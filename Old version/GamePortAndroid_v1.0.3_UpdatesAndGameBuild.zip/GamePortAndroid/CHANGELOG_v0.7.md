# v0.7.0 — ZIP import, game launcher shell, real touch controller

- versionCode 7 / versionName 0.7.0 (v0.6 was versionCode 6, so this installs as an update; same package ID, same signing key required).
- New: "Port a game ZIP" screen. Picks a .zip, unpacks it into private app storage (zip-slip protected), finds the main game .exe, saves it to a ported-games list.
- New: per-game Play button and pinned home-screen icon (one app, one signing key, simple updates).
- New: working multitouch controller (move stick -> WASD, drag to look, fire/aim/jump/reload/crouch/use/menu). Uses the saved size/opacity from the designer.
- New: RuntimeBridge interface. A Wine + Box64 + Vulkan runtime plugs in here. Until one is bundled, Play opens the game screen and shows live input events.
- NOT done: the runtime itself. Nothing launches the game exe yet.
- Source only: not compiled or run on a device in the environment that produced it.
