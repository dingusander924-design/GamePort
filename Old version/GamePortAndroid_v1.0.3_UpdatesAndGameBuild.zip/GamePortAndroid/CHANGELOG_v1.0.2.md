# GamePort 1.0.2 — updates that install over the old app + cloud game-APK workflow

- Permanent signing key (app/gameport-signing.p12) for every build, so a new APK installs as an update over the old one and keeps imported games. Package ID stays com.gameport.mobile; versionCode = 1000 + GitHub run number.
- Uninstall the old GamePort once when switching to this key (earlier builds used a random key). Keep the GitHub repo private: the key is inside it.
- Removed GamePortAndroid/.github/workflows/build-apk.yml. GitHub only runs workflows from the repo's top-level .github/workflows folder, so it never ran. The repo-root build.yml (see README) now does everything.
- New root build.yml: push = build GamePort and publish a GitHub Release with GamePort.apk (one-tap download). Manual run with a game package name = build a per-game Winlator APK in the cloud, signed with the same key, published as a Release.
- Cloud game build clones the public winlator-app source, runs tools/gameport_winlator_fork.py to make the per-game project, installs SDK 35 / build-tools 35.0.0 / NDK 24.0.8215888 / CMake 3.22.1, then runs Gradle online (the tool's own --offline build mode cannot work in CI). If the Winlator source does not carry its runtime assets, they are copied from the official Winlator 11.2 release APK.
- Untested: nothing here was compiled or run in the environment that wrote it.
- Removed tools/test_ci_workflow.py (it tested the deleted inner workflow file).
