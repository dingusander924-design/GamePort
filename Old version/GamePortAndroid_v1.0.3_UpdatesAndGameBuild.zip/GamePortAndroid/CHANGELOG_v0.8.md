> Historical v0.8 proposal: the APK-cloning approach described below was later found to create a GamePort shell, not a Windows-game runtime APK. It was removed in v1.0.0 Build Pipeline Preview.

# v0.8.0 — standalone game APKs

- versionCode 8 / 0.8.0 (installs over v0.7).
- New "Build standalone game APK" on every ported game. GamePort copies its own APK, gives the copy a new package ID and the game's name, adds a small game config, signs it with a key stored in the Android Keystore, and offers Install (system confirm screen) or Save APK file (to hand to friends).
- The built app is the game's own app: it has no GamePort screens. First launch downloads the runtime pack (set RuntimePack.PACK_URL), then asks for the player's own game ZIP once and unpacks it into the app's private storage. After that it opens straight into the game with the touch controls.
- The game's files are never inside the APK.
- Rebuilding the same game keeps the same package ID, so installs update in place.
- Not done: the runtime pack itself (nothing launches the exe yet), a per-game icon (default icon for now).
- Source only: not compiled or tested on a device where it was written. New dependency: apksig (Google Maven).

## 0.8.1 build fix
- Java and Kotlin now both target JVM 17 (fixes the "Inconsistent JVM-target" build error on GitHub Actions).
- Small compile-safety fixes in the new files.

## 0.8.2 build fix
- MainActivity label() helper now accepts whole-number text sizes (fixes ~30 "Int but Float expected" compile errors from the GitHub build log).

## 0.8.3
- App icon: new GamePort logo as an adaptive launcher icon (also used by standalone game APKs for now).
