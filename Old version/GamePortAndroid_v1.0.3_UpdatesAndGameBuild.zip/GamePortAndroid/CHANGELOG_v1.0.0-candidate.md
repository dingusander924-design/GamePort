# GamePort 1.0.0 — Build Pipeline Preview

## Corrected the APK forge behavior
- Removed the old APK cloning forge that copied GamePort itself and only redirected into its own game-mode screen. It did not bundle a Windows compatibility runtime.
- Removed the APK installer flow for those cloned GamePort APKs.
- The game card's Play action is now labeled **Test controls** because its runtime bridge is still a sandbox, not a Windows runtime.

## Game package export
- Added **Export Winlator build package** to game cards.
- Exports a versioned JSON manifest and nested game-payload ZIP.
- Validates executable path before packaging, canonicalizes paths, checks file count and total size, and cleans temporary payload ZIPs.

## Winlator source-project builder
- Added `tools/gameport_winlator_fork.py`.
- Generates a per-game Winlator source fork from the provided upstream source ZIP and exported game package.
- Customizes package ID, app title, version code/name, embeds the payload and manifest, adds first-run container creation and direct-launch bootstrap, and patches root filesystem installation to callback on successful completion.
- Stable package ID derives from game title + executable path; payload hash is stored separately so changed payload can be merged during updates without deleting user files.
- Rejects unsafe paths, duplicate payload names, symlinks, missing EXE, oversized payloads, and unsupported package schema.
- `--build-apk` only attempts to build when a local system Gradle/JDK/SDK/NDK/CMake toolchain is present; it never runs or downloads an unverified wrapper distribution. If blocked, the source-project ZIP is still produced and CRC-checked.

## Verification performed
- 10 Python unit tests passed.
- Generated bootstrap Java compiled against API stubs.
- Generator was run against the actual uploaded Winlator source archive and a test game package; project patching and assets were verified.
- Generated project source ZIP tested with CRC.
- Kotlin parser run on the changed PortActivity; no Kotlin syntax error markers were reported. Full Android type/compile check is blocked by missing Android SDK/Gradle dependencies.
- Toolchain preflight found no system Gradle, no Android SDK, no JDK 17 (Java 21 present); Android Build Tools/NDK/CMake not available.
- No game APK was compiled, installed, or device-tested.
