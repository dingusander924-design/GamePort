# v0.9.0 — one permanent signing key, polished UI

- Updates: every build is now signed with the same key (app/gameport-signing.p12) and versionCode grows with each GitHub build (100 + run number), so each new APK installs as an update over the old one. Uninstall once when switching to this version (earlier builds used a random key); after that updates keep your imported games.
- Keep the GitHub repo private: the signing key is inside it.
- UI: new shared look (Ui.kt): deep navy with logo-blue accents, rounded cards, ripple buttons, logo header, spacing in dp, content kept clear of the status/navigation bars, progress bar while importing/building, delete confirmation, game cards with letter tiles.
- All screens restyled: home, Port a game ZIP, and the first-launch screen of standalone game APKs.
- Standalone game APKs still carry the GamePort logo for now.
